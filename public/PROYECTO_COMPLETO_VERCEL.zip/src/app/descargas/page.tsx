"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileArchive, FileText, CheckCircle } from "lucide-react";
import Link from "next/link";

export default function DescargasPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white p-4 sm:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <img src="/logo.png" alt="CyJ Logo" className="h-16 w-auto" />
          </div>
          <h1 className="text-3xl font-bold text-emerald-800 mb-2">
            Descargas - Sistema CyJ
          </h1>
          <p className="text-gray-600">
            Todo lo que necesitas para poner tu sistema en producción
          </p>
        </div>

        {/* Archivo Principal */}
        <Card className="mb-6 border-2 border-emerald-500 shadow-lg">
          <CardHeader className="bg-emerald-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2 text-xl">
              <FileArchive className="h-6 w-6" />
              📦 ARCHIVO PRINCIPAL - DESCARGA AQUÍ
            </CardTitle>
            <CardDescription className="text-emerald-100">
              Este archivo contiene TODO lo que necesitas
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="flex-1">
                <h3 className="font-bold text-lg mb-2">SISTEMA_CYJ_COMPLETO.zip</h3>
                <p className="text-gray-600 mb-3">Tamaño: ~2.2 MB</p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>✅ Sistema completo (código fuente)</li>
                  <li>✅ Instrucciones paso a paso</li>
                  <li>✅ Guía visual con dibujos</li>
                  <li>✅ Archivos de configuración</li>
                </ul>
              </div>
              <a 
                href="/descargas/SISTEMA_CYJ_COMPLETO.zip" 
                download
                className="w-full sm:w-auto"
              >
                <Button size="lg" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-lg py-6 px-8">
                  <Download className="mr-2 h-5 w-5" />
                  DESCARGAR TODO
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Contenido del ZIP */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              ¿Qué contiene el archivo?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                <FileArchive className="h-5 w-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="font-medium">PARA_SUBIR_A_VERCEL.zip</p>
                  <p className="text-sm text-gray-600">Tu sistema completo - Descomprime y sube a GitHub</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                <FileText className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <p className="font-medium">RESUMEN_SIMPLE.txt</p>
                  <p className="text-sm text-gray-600">Resumen rápido en 5 pasos</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
                <FileText className="h-5 w-5 text-yellow-600 mt-0.5" />
                <div>
                  <p className="font-medium">INSTRUCCIONES_SIMPLES.txt</p>
                  <p className="text-sm text-gray-600">Guía detallada para principiantes</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
                <FileText className="h-5 w-5 text-purple-600 mt-0.5" />
                <div>
                  <p className="font-medium">GUIA_VISUAL.txt</p>
                  <p className="text-sm text-gray-600">Dibujos de lo que verás en cada pantalla</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
                <FileText className="h-5 w-5 text-red-600 mt-0.5" />
                <div>
                  <p className="font-medium">VARIABLES_QUE_NECESITAS.txt</p>
                  <p className="text-sm text-gray-600">Las 3 variables para configurar en Vercel</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pasos rápidos */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>📋 Pasos después de descargar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-600 text-white font-bold">1</span>
                <p>Descomprime el archivo SISTEMA_CYJ_COMPLETO.zip</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-600 text-white font-bold">2</span>
                <p>Lee RESUMEN_SIMPLE.txt para entender el proceso</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-600 text-white font-bold">3</span>
                <p>Descomprime PARA_SUBIR_A_VERCEL.zip</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-600 text-white font-bold">4</span>
                <p>Sube TODO a GitHub → Conecta con Vercel → ¡Listo!</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Resumen de plataformas */}
        <div className="grid sm:grid-cols-3 gap-4 mb-6">
          <Card className="text-center">
            <CardContent className="p-4">
              <div className="text-4xl mb-2">🐙</div>
              <h3 className="font-bold">GitHub</h3>
              <p className="text-sm text-gray-600">Donde guardas el código</p>
              <p className="text-xs text-emerald-600 mt-1">github.com</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <div className="text-4xl mb-2">🗄️</div>
              <h3 className="font-bold">Neon</h3>
              <p className="text-sm text-gray-600">Base de datos gratis</p>
              <p className="text-xs text-emerald-600 mt-1">neon.tech</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <div className="text-4xl mb-2">▲</div>
              <h3 className="font-bold">Vercel</h3>
              <p className="text-sm text-gray-600">Donde funciona tu sistema</p>
              <p className="text-xs text-emerald-600 mt-1">vercel.com</p>
            </CardContent>
          </Card>
        </div>

        {/* Botón volver */}
        <div className="text-center">
          <Link href="/">
            <Button variant="outline" className="gap-2">
              ← Volver al Sistema
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
