'use client'

import { useEffect, useState, useMemo, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Plus, Pencil, Trash2, Search, Upload, Phone, Mail, ChevronDown, ChevronUp, Filter } from 'lucide-react'
import { useSession } from '@/hooks/use-session'
import { useIsMobile } from '@/hooks/use-mobile'
import { ExportButton, exportUtils, type ColumnConfig } from '@/components/shared/ExportButton'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'

interface Residente {
  id: string
  nombre: string
  apellido?: string | null
  rut: string | null
  unidad: string | null
  etapa: string | null
  tipo: string
  telefono: string | null
  email: string | null
  fechaIngreso: string | null
  estado: string
  vehiculos?: string | null
  notas: string | null
}

const tipoColors: Record<string, string> = {
  'Residente': 'bg-blue-100 text-blue-700',
  'Propietario': 'bg-green-100 text-green-700',
  'Arrendatario': 'bg-purple-100 text-purple-700',
  'Visita': 'bg-slate-100 text-slate-700',
}

const estadoColors: Record<string, string> = {
  'Activo': 'bg-green-100 text-green-700',
  'Moroso': 'bg-red-100 text-red-700',
  'Vacaciones': 'bg-cyan-100 text-cyan-700',
  'Licencia': 'bg-purple-100 text-purple-700',
  'Inactivo': 'bg-slate-100 text-slate-700',
}

const formatDate = (d: string | null) => {
  if (!d) return '–'
  try {
    const [y, m, dd] = d.split('-')
    return `${dd}/${m}/${y}`
  } catch {
    return d
  }
}

// Extraer letra de unidad (ej: "A-101" -> "A", "B-201" -> "B")
const extractLetraUnidad = (unidad: string | null): string => {
  if (!unidad) return ''
  const match = unidad.match(/^([A-Za-z])/)
  return match ? match[1].toUpperCase() : ''
}

export function ResidentesModule() {
  const [residentes, setResidentes] = useState<Residente[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterLetra, setFilterLetra] = useState('todas')
  const [filterEtapa, setFilterEtapa] = useState('todas')
  const [filterTipo, setFilterTipo] = useState('todos')
  const [filterEstado, setFilterEstado] = useState('todos')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [importDialogOpen, setImportDialogOpen] = useState(false)
  const [importStatus, setImportStatus] = useState<{ loading: boolean; message: string }>({ loading: false, message: '' })
  const [editingRes, setEditingRes] = useState<Residente | null>(null)
  const [filtersOpen, setFiltersOpen] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const isMobile = useIsMobile()
  
  const { hasPermission } = useSession()
  const canEdit = hasPermission('residentes.editar')
  
  const [formData, setFormData] = useState({
    nombre: '',
    apellido: '',
    rut: '',
    unidad: '',
    etapa: '',
    tipo: 'Residente',
    telefono: '',
    email: '',
    fechaIngreso: new Date().toISOString().split('T')[0],
    estado: 'Activo',
    vehiculos: '',
    notas: '',
  })

  const fetchResidentes = async (searchTerm = '') => {
    setLoading(true)
    try {
      const url = searchTerm ? `/api/residentes?search=${encodeURIComponent(searchTerm)}` : '/api/residentes'
      const res = await fetch(url)
      const responseData = await res.json()
      
      // CORREGIDO: La API devuelve { data: [...], pagination: {...} }
      if (responseData && Array.isArray(responseData.data)) {
        setResidentes(responseData.data)
      } else if (Array.isArray(responseData)) {
        setResidentes(responseData)
      } else if (responseData && Array.isArray(responseData.residentes)) {
        setResidentes(responseData.residentes)
      } else {
        console.error('API returned unexpected format:', responseData)
        setResidentes([])
      }
    } catch (error) {
      console.error('Error fetching residentes:', error)
      setResidentes([])
    }
    setLoading(false)
  }

  useEffect(() => {
    void (async () => {
      await fetchResidentes()
    })()
  }, [])

  useEffect(() => {
    const timeout = setTimeout(() => fetchResidentes(search), 300)
    return () => clearTimeout(timeout)
  }, [search])

  // Obtener etapas únicas - CORREGIDO: Validar que residentes sea un array
  const etapasUnicas = useMemo(() => {
    const etapas = new Set<string>()
    if (!Array.isArray(residentes)) return []
    residentes.forEach(r => {
      if (r?.etapa) etapas.add(r.etapa)
    })
    return Array.from(etapas).sort()
  }, [residentes])

  // Obtener letras únicas de unidades - CORREGIDO: Validar que residentes sea un array
  const letrasUnicas = useMemo(() => {
    const letras = new Set<string>()
    if (!Array.isArray(residentes)) return []
    residentes.forEach(r => {
      const letra = extractLetraUnidad(r?.unidad)
      if (letra) letras.add(letra)
    })
    return Array.from(letras).sort()
  }, [residentes])

  // Filtrar residentes - CORREGIDO: Validar que residentes sea un array
  const residentesFiltrados = useMemo(() => {
    if (!Array.isArray(residentes)) return []
    return residentes.filter(r => {
      if (!r) return false
      const matchLetra = filterLetra === 'todas' || extractLetraUnidad(r.unidad) === filterLetra
      const matchEtapa = filterEtapa === 'todas' || 
        (filterEtapa === 'sin-etapa' ? !r.etapa : r.etapa === filterEtapa)
      const matchTipo = filterTipo === 'todos' || r.tipo === filterTipo
      const matchEstado = filterEstado === 'todos' || r.estado === filterEstado
      return matchLetra && matchEtapa && matchTipo && matchEstado
    })
  }, [residentes, filterLetra, filterEtapa, filterTipo, filterEstado])

  // Estadísticas por etapa - CORREGIDO: Validar que residentes sea un array
  const statsPorEtapa = useMemo(() => {
    const stats: Record<string, number> = {}
    if (!Array.isArray(residentes)) return stats
    residentes.forEach(r => {
      if (!r) return
      const etapa = r.etapa || 'Sin Etapa'
      stats[etapa] = (stats[etapa] || 0) + 1
    })
    return stats
  }, [residentes])

  // Estadísticas por letra - CORREGIDO: Validar que residentes sea un array
  const statsPorLetra = useMemo(() => {
    const stats: Record<string, number> = {}
    if (!Array.isArray(residentes)) return stats
    residentes.forEach(r => {
      if (!r) return
      const letra = extractLetraUnidad(r.unidad) || 'Sin Letra'
      stats[letra] = (stats[letra] || 0) + 1
    })
    return stats
  }, [residentes])

  const openDialog = (res?: Residente) => {
    if (res) {
      setEditingRes(res)
      setFormData({
        nombre: res.nombre,
        apellido: res.apellido || '',
        rut: res.rut || '',
        unidad: res.unidad || '',
        etapa: res.etapa || '',
        tipo: res.tipo,
        telefono: res.telefono || '',
        email: res.email || '',
        fechaIngreso: res.fechaIngreso || new Date().toISOString().split('T')[0],
        estado: res.estado,
        vehiculos: res.vehiculos || '',
        notas: res.notas || '',
      })
    } else {
      setEditingRes(null)
      setFormData({
        nombre: '',
        apellido: '',
        rut: '',
        unidad: '',
        etapa: '',
        tipo: 'Residente',
        telefono: '',
        email: '',
        fechaIngreso: new Date().toISOString().split('T')[0],
        estado: 'Activo',
        vehiculos: '',
        notas: '',
      })
    }
    setDialogOpen(true)
  }

  const handleSave = async () => {
    if (!formData.nombre.trim()) return

    try {
      if (editingRes) {
        await fetch(`/api/residentes/${editingRes.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
      } else {
        await fetch('/api/residentes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
      }
      setDialogOpen(false)
      fetchResidentes(search)
    } catch (error) {
      console.error('Error saving residente:', error)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar este residente?')) return
    try {
      await fetch(`/api/residentes/${id}`, { method: 'DELETE' })
      fetchResidentes(search)
    } catch (error) {
      console.error('Error deleting residente:', error)
    }
  }

  // Importar desde Excel
  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setImportStatus({ loading: true, message: 'Procesando archivo...' })

    try {
      // Leer archivo Excel usando SheetJS (dinámico)
      const XLSX = await import('xlsx')
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data)
      const sheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[sheetName]
      const jsonData = XLSX.utils.sheet_to_json(worksheet)

      // Enviar al API
      const response = await fetch('/api/import/residentes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ residentes: jsonData }),
      })

      const result = await response.json()

      if (result.success) {
        setImportStatus({ 
          loading: false, 
          message: result.mensaje 
        })
        fetchResidentes()
      } else {
        setImportStatus({ 
          loading: false, 
          message: `Error: ${result.error}` 
        })
      }
    } catch (error) {
      console.error('Error importing:', error)
      setImportStatus({ 
        loading: false, 
        message: 'Error al procesar el archivo' 
      })
    }

    // Limpiar input
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  // Export configuration
  const exportColumns: ColumnConfig[] = [
    { key: 'nombre', label: 'Nombre', defaultVisible: true },
    { key: 'apellido', label: 'Apellido', defaultVisible: true },
    { key: 'rut', label: 'RUT', defaultVisible: true },
    { key: 'unidad', label: 'Unidad', defaultVisible: true },
    { key: 'etapa', label: 'Etapa', defaultVisible: true },
    { key: 'tipo', label: 'Tipo', defaultVisible: true },
    { key: 'telefono', label: 'Teléfono', defaultVisible: true },
    { key: 'email', label: 'Email', defaultVisible: true },
    { key: 'estado', label: 'Estado', defaultVisible: true },
    { key: 'fechaIngreso', label: 'Fecha Ingreso', defaultVisible: false },
    { key: 'vehiculos', label: 'Vehículos', defaultVisible: false },
    { key: 'notas', label: 'Notas', defaultVisible: false },
  ]

  const handleExport = async (config: { format: 'csv' | 'excel' | 'pdf'; columns: string[]; filters: Record<string, string> }) => {
    const dataToExport = residentesFiltrados.length > 0 ? residentesFiltrados : residentes
    if (config.format === 'csv') {
      const csv = exportUtils.toCSV(dataToExport, exportColumns, config.columns)
      exportUtils.downloadFile(csv, `residentes_${Date.now()}.csv`, 'text/csv;charset=utf-8')
    } else if (config.format === 'pdf') {
      const html = exportUtils.generatePDFHTML(dataToExport, exportColumns, config.columns, 'Residentes', config.filters)
      exportUtils.printPDF(html)
    } else {
      const csv = exportUtils.toCSV(dataToExport, exportColumns, config.columns)
      exportUtils.downloadFile(csv, `residentes_${Date.now()}.xlsx`, 'application/vnd.ms-excel')
    }
  }

  // Render mobile card
  const renderMobileCard = (res: Residente) => {
    const letraUnidad = extractLetraUnidad(res.unidad)
    
    return (
      <Card key={res.id} className="mb-3">
        <CardContent className="p-3">
          <div className="flex items-start gap-3">
            <Avatar className="h-10 w-10 bg-[#0f2040] text-white text-sm font-bold shrink-0">
              <AvatarFallback className="bg-[#0f2040] text-white">
                {res.nombre.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-sm truncate">{res.nombre} {res.apellido || ''}</span>
                <Badge className={`${estadoColors[res.estado] || 'bg-slate-100'} text-[9px]`}>
                  {res.estado}
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-600 mb-2">
                {letraUnidad && (
                  <div className="w-5 h-5 rounded bg-[#0f2040] text-white text-[10px] font-bold flex items-center justify-center">
                    {letraUnidad}
                  </div>
                )}
                <span className="font-medium">{res.unidad || '–'}</span>
                {res.etapa && (
                  <Badge className="bg-emerald-100 text-emerald-700 text-[9px]">{res.etapa}</Badge>
                )}
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-500">
                <Badge className={`${tipoColors[res.tipo] || 'bg-slate-100'} text-[9px]`}>
                  {res.tipo}
                </Badge>
                {res.telefono && (
                  <span className="flex items-center gap-1">
                    <Phone className="w-3 h-3" />
                    {res.telefono}
                  </span>
                )}
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openDialog(res)}>
                <Pencil className="w-4 h-4" />
              </Button>
              <Button size="icon" variant="ghost" className="h-8 w-8 text-red-600" onClick={() => handleDelete(res.id)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Stats por Etapa */}
      {etapasUnicas.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-xs sm:text-sm font-semibold text-slate-600">Por Etapa</h3>
          <div className="flex gap-2 flex-wrap">
            {etapasUnicas.map(etapa => (
              <Card 
                key={etapa} 
                className={`px-2 sm:px-3 py-1.5 sm:py-2 cursor-pointer transition-all ${
                  filterEtapa === etapa ? 'ring-2 ring-amber-500 bg-amber-50' : 'hover:bg-slate-50'
                }`}
                onClick={() => setFilterEtapa(filterEtapa === etapa ? 'todas' : etapa)}
              >
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <div className="w-5 h-5 sm:w-6 sm:h-6 rounded bg-emerald-500 text-white text-[10px] sm:text-xs font-bold flex items-center justify-center">
                    {etapa.charAt(0)}
                  </div>
                  <span className="text-xs sm:text-sm font-medium">{etapa}</span>
                  <Badge variant="secondary" className="text-[10px]">{statsPorEtapa[etapa] || 0}</Badge>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Stats por Letra de Unidad */}
      {letrasUnicas.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-xs sm:text-sm font-semibold text-slate-600">Por Letra de Unidad</h3>
          <div className="flex gap-2 flex-wrap">
            {letrasUnicas.map(letra => (
              <Card 
                key={letra} 
                className={`px-2 sm:px-3 py-1.5 sm:py-2 cursor-pointer transition-all ${
                  filterLetra === letra ? 'ring-2 ring-amber-500 bg-amber-50' : 'hover:bg-slate-50'
                }`}
                onClick={() => setFilterLetra(filterLetra === letra ? 'todas' : letra)}
              >
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <div className="w-5 h-5 sm:w-6 sm:h-6 rounded bg-[#0f2040] text-white text-[10px] sm:text-xs font-bold flex items-center justify-center">
                    {letra}
                  </div>
                  <span className="text-xs sm:text-sm font-semibold">{statsPorLetra[letra] || 0}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 max-w-xs min-w-[150px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Buscar..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-9"
          />
        </div>
        
        {isMobile ? (
          <Collapsible open={filtersOpen} onOpenChange={setFiltersOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="outline" size="sm" className="h-9">
                <Filter className="w-4 h-4 mr-1" />
                Filtros
                {filtersOpen ? <ChevronUp className="w-3 h-3 ml-1" /> : <ChevronDown className="w-3 h-3 ml-1" />}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2 space-y-2">
              <div className="flex gap-2">
                <Select value={filterTipo} onValueChange={setFilterTipo}>
                  <SelectTrigger className="w-full h-9">
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos los tipos</SelectItem>
                    {['Residente', 'Propietario', 'Arrendatario', 'Visita'].map(t => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={filterEstado} onValueChange={setFilterEstado}>
                  <SelectTrigger className="w-full h-9">
                    <SelectValue placeholder="Estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos los estados</SelectItem>
                    {['Activo', 'Moroso', 'Vacaciones', 'Licencia', 'Inactivo'].map(s => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CollapsibleContent>
          </Collapsible>
        ) : (
          <>
            <Select value={filterTipo} onValueChange={setFilterTipo}>
              <SelectTrigger className="w-32 h-9">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos los tipos</SelectItem>
                {['Residente', 'Propietario', 'Arrendatario', 'Visita'].map(t => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterEstado} onValueChange={setFilterEstado}>
              <SelectTrigger className="w-32 h-9">
                <SelectValue placeholder="Estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos los estados</SelectItem>
                {['Activo', 'Moroso', 'Vacaciones', 'Licencia', 'Inactivo'].map(s => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <ExportButton
              moduleName="residentes"
              moduleLabel="Residentes"
              columns={exportColumns}
              data={residentesFiltrados.length > 0 ? residentesFiltrados : residentes}
              totalRecords={residentes.length}
              onExport={handleExport}
            />
            <Button variant="outline" size="sm" className="h-9" onClick={() => setImportDialogOpen(true)}>
              <Upload className="w-4 h-4 mr-1" /> Importar
            </Button>
          </>
        )}
        <Button size="sm" className="h-9" onClick={() => openDialog()}>
          <Plus className="w-4 h-4 mr-1" /> Nuevo
        </Button>
      </div>

      {/* Conteo de filtros activos */}
      {(filterLetra !== 'todas' || filterEtapa !== 'todas' || filterTipo !== 'todos' || filterEstado !== 'todos') && (
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span>{residentesFiltrados.length} de {residentes.length} residentes</span>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-6 text-xs"
            onClick={() => {
              setFilterLetra('todas')
              setFilterEtapa('todas')
              setFilterTipo('todos')
              setFilterEstado('todos')
            }}
          >
            Limpiar
          </Button>
        </div>
      )}

      {/* Mobile Cards or Desktop Table */}
      {isMobile ? (
        <div className="space-y-2">
          {loading ? (
            <div className="p-8 text-center text-slate-400 text-sm">Cargando...</div>
          ) : residentesFiltrados.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm">Sin residentes</div>
          ) : (
            residentesFiltrados.map(renderMobileCard)
          )}
        </div>
      ) : (
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-sm">Residentes ({residentesFiltrados.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-slate-50 z-10">
                  <tr className="border-b">
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Nombre</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">RUT</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Unidad</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Etapa</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Tipo</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Estado</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Teléfono</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Email</th>
                    <th className="text-center p-3 text-[10px] font-bold text-slate-500 uppercase">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={9} className="p-8 text-center text-slate-400">Cargando...</td></tr>
                  ) : residentesFiltrados.length === 0 ? (
                    <tr><td colSpan={9} className="p-8 text-center text-slate-400">Sin residentes</td></tr>
                  ) : (
                    residentesFiltrados.map((res) => {
                      const letraUnidad = extractLetraUnidad(res.unidad)
                      
                      return (
                        <tr key={res.id} className="border-b last:border-0 hover:bg-slate-50">
                          <td className="p-3">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-7 w-7">
                                <AvatarFallback className="bg-[#0f2040] text-white text-xs font-bold">
                                  {res.nombre.charAt(0)}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-semibold">{res.nombre}</span>
                            </div>
                          </td>
                          <td className="p-3 font-mono text-xs">{res.rut || '–'}</td>
                          <td className="p-3">
                            <div className="flex items-center gap-2">
                              {letraUnidad && (
                                <div className="w-5 h-5 rounded bg-[#0f2040] text-white text-[10px] font-bold flex items-center justify-center">
                                  {letraUnidad}
                                </div>
                              )}
                              <span className="font-semibold">{res.unidad || '–'}</span>
                            </div>
                          </td>
                          <td className="p-3">
                            {res.etapa ? (
                              <Badge className="bg-emerald-100 text-emerald-700">{res.etapa}</Badge>
                            ) : '–'}
                          </td>
                          <td className="p-3">
                            <Badge className={tipoColors[res.tipo] || 'bg-slate-100'}>{res.tipo}</Badge>
                          </td>
                          <td className="p-3">
                            <Badge className={estadoColors[res.estado] || 'bg-slate-100'}>{res.estado}</Badge>
                          </td>
                          <td className="p-3 text-xs">{res.telefono || '–'}</td>
                          <td className="p-3 text-xs">{res.email || '–'}</td>
                          <td className="p-3">
                            <div className="flex justify-center gap-1">
                              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openDialog(res)}>
                                <Pencil className="w-3.5 h-3.5" />
                              </Button>
                              <Button size="icon" variant="ghost" className="h-7 w-7 text-red-600 hover:text-red-700" onClick={() => handleDelete(res.id)}>
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Edit/Create Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base">{editingRes ? 'Editar' : 'Nuevo'} Residente</DialogTitle>
          </DialogHeader>
          <div className="grid gap-3 py-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Nombre</Label>
                <Input value={formData.nombre} onChange={(e) => setFormData({...formData, nombre: e.target.value})} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Apellido</Label>
                <Input value={formData.apellido} onChange={(e) => setFormData({...formData, apellido: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">RUT</Label>
                <Input placeholder="12.345.678-9" value={formData.rut} onChange={(e) => setFormData({...formData, rut: e.target.value})} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Unidad</Label>
                <Input value={formData.unidad} onChange={(e) => setFormData({...formData, unidad: e.target.value})} placeholder="Ej: A-101" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Etapa</Label>
                <Select value={formData.etapa || 'sin-etapa'} onValueChange={(v) => setFormData({...formData, etapa: v === 'sin-etapa' ? '' : v})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar etapa" />
                  </SelectTrigger>
                  <SelectContent>
                    {etapasUnicas.map(e => (
                      <SelectItem key={e} value={e}>{e}</SelectItem>
                    ))}
                    <SelectItem value="sin-etapa">Sin etapa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Tipo</Label>
                <Select value={formData.tipo} onValueChange={(v) => setFormData({...formData, tipo: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['Residente', 'Propietario', 'Arrendatario', 'Visita'].map(t => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Estado</Label>
                <Select value={formData.estado} onValueChange={(v) => setFormData({...formData, estado: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['Activo', 'Moroso', 'Vacaciones', 'Licencia', 'Inactivo'].map(s => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Fecha Ingreso</Label>
                <Input type="date" value={formData.fechaIngreso} onChange={(e) => setFormData({...formData, fechaIngreso: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Teléfono</Label>
                <Input value={formData.telefono} onChange={(e) => setFormData({...formData, telefono: e.target.value})} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Email</Label>
                <Input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Vehículos</Label>
              <Input value={formData.vehiculos} onChange={(e) => setFormData({...formData, vehiculos: e.target.value})} placeholder="Patentes o descripción" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Notas</Label>
              <Textarea value={formData.notas} onChange={(e) => setFormData({...formData, notas: e.target.value})} rows={2} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleSave}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import Dialog */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-base">Importar Residentes desde Excel</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-3">
            <div className="bg-slate-50 p-3 rounded-lg text-xs">
              <p className="font-semibold mb-2">Formato esperado del archivo Excel:</p>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>• <strong>Nombre:</strong> Nombre del residente</li>
                <li>• <strong>Apellidos:</strong> Apellidos</li>
                <li>• <strong>RUT:</strong> RUT del residente</li>
                <li>• <strong>Casa_Depto:</strong> Número de unidad</li>
                <li>• <strong>Etapa:</strong> Etapa del condominio</li>
                <li>• <strong>Telefono:</strong> Teléfono de contacto</li>
                <li>• <strong>Tipo_Residente:</strong> Propietario, Arrendatario, etc.</li>
              </ul>
            </div>
            
            <input
              type="file"
              accept=".xlsx,.xls"
              ref={fileInputRef}
              onChange={handleImport}
              className="hidden"
            />
            
            <Button 
              onClick={() => fileInputRef.current?.click()}
              disabled={importStatus.loading}
              className="w-full"
              size="sm"
            >
              {importStatus.loading ? (
                <>Procesando...</>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Seleccionar archivo Excel (.xlsx)
                </>
              )}
            </Button>
            
            {importStatus.message && (
              <div className={`p-3 rounded-lg text-xs ${
                importStatus.message.includes('Error') 
                  ? 'bg-red-50 text-red-700' 
                  : 'bg-green-50 text-green-700'
              }`}>
                {importStatus.message}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => {
              setImportDialogOpen(false)
              setImportStatus({ loading: false, message: '' })
            }}>
              Cerrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
