'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { 
  Plus, Pencil, Trash2, Download, Search, Upload, 
  FileUp, CheckCircle, X, Check, 
  Loader2, Building2
} from 'lucide-react'
import { useIsMobile } from '@/hooks/use-mobile'
import { cn } from '@/lib/utils'

interface CentroCosto {
  id: string
  codigo: string
  nombre: string
  descripcion: string | null
  responsable: string | null
  tipoGasto: string
  presupuestoMens: number
  presupuestoAnual: number
  estado: string
}

interface Gasto {
  centroCostoId: string | null
  monto: number
}

interface PreviewRow {
  original: Record<string, unknown>
  mapped: {
    codigo: string | null
    nombre: string | null
    descripcion: string | null
    responsable: string | null
    tipoGasto: string
    presupuestoMens: number
    presupuestoAnual: number
    estado: string
  }
  valid: boolean
  errors: string[]
  willCreate: boolean
}

const formatCLP = (n: number) => 
  '$' + new Intl.NumberFormat('es-CL').format(Math.round(n || 0))

const estadoColors: Record<string, string> = {
  'Activo': 'bg-green-100 text-green-700',
  'Inactivo': 'bg-slate-100 text-slate-700',
  'Cerrado': 'bg-red-100 text-red-700',
}

const tipoGastoColors: Record<string, string> = {
  'Fijo': 'bg-blue-100 text-blue-700',
  'Variable': 'bg-purple-100 text-purple-700',
  'Contrato': 'bg-amber-100 text-amber-700',
  'Estacional': 'bg-cyan-100 text-cyan-700',
  'Fondo de Reserva': 'bg-rose-100 text-rose-700',
}

const tiposGasto = ['Fijo', 'Variable', 'Contrato', 'Estacional', 'Fondo de Reserva']
const estados = ['Activo', 'Inactivo', 'Cerrado']

export function CentroCostoModule() {
  const [centros, setCentros] = useState<CentroCosto[]>([])
  const [gastos, setGastos] = useState<Gasto[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterEstado, setFilterEstado] = useState('todos')
  const [filterTipo, setFilterTipo] = useState('todos')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [editingCentro, setEditingCentro] = useState<CentroCosto | null>(null)
  const [deletingCentro, setDeletingCentro] = useState<CentroCosto | null>(null)
  const [formData, setFormData] = useState({
    codigo: '',
    nombre: '',
    descripcion: '',
    responsable: '',
    tipoGasto: 'Variable',
    presupuestoMens: 0,
    presupuestoAnual: 0,
    estado: 'Activo',
  })
  
  // Bulk import states
  const [importDialogOpen, setImportDialogOpen] = useState(false)
  const [previewData, setPreviewData] = useState<PreviewRow[]>([])
  const [importStep, setImportStep] = useState<'upload' | 'preview' | 'importing' | 'result'>('upload')
  const [importFile, setImportFile] = useState<File | null>(null)
  const [importResult, setImportResult] = useState<{creados: number, actualizados: number, errores: string[]} | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const isMobile = useIsMobile()

  const fetchData = async () => {
    setLoading(true)
    try {
      const [centrosRes, gastosRes] = await Promise.all([
        fetch('/api/centros-costo'),
        fetch('/api/gastos'),
      ])
      setCentros(await centrosRes.json())
      setGastos(await gastosRes.json())
    } catch (error) {
      console.error('Error fetching data:', error)
    }
    setLoading(false)
  }

  useEffect(() => {
    void (async () => {
      await fetchData()
    })()
  }, [])

  // Filtrar centros
  const filteredCentros = centros.filter(c => {
    const matchSearch = !search || 
      c.nombre.toLowerCase().includes(search.toLowerCase()) ||
      c.codigo.toLowerCase().includes(search.toLowerCase()) ||
      (c.descripcion && c.descripcion.toLowerCase().includes(search.toLowerCase())) ||
      (c.responsable && c.responsable.toLowerCase().includes(search.toLowerCase()))
    const matchEstado = filterEstado === 'todos' || c.estado === filterEstado
    const matchTipo = filterTipo === 'todos' || c.tipoGasto === filterTipo
    return matchSearch && matchEstado && matchTipo
  })

  const openDialog = (centro?: CentroCosto) => {
    if (centro) {
      setEditingCentro(centro)
      setFormData({
        codigo: centro.codigo,
        nombre: centro.nombre,
        descripcion: centro.descripcion || '',
        responsable: centro.responsable || '',
        tipoGasto: centro.tipoGasto,
        presupuestoMens: centro.presupuestoMens,
        presupuestoAnual: centro.presupuestoAnual,
        estado: centro.estado,
      })
    } else {
      setEditingCentro(null)
      setFormData({
        codigo: '',
        nombre: '',
        descripcion: '',
        responsable: '',
        tipoGasto: 'Variable',
        presupuestoMens: 0,
        presupuestoAnual: 0,
        estado: 'Activo',
      })
    }
    setDialogOpen(true)
  }

  const openDeleteDialog = (centro: CentroCosto) => {
    setDeletingCentro(centro)
    setDeleteDialogOpen(true)
  }

  const handleSave = async () => {
    if (!formData.nombre.trim() || !formData.codigo.trim()) return

    try {
      if (editingCentro) {
        await fetch(`/api/centros-costo/${editingCentro.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
      } else {
        await fetch('/api/centros-costo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
      }
      setDialogOpen(false)
      fetchData()
    } catch (error) {
      console.error('Error saving centro:', error)
    }
  }

  const handleDelete = async () => {
    if (!deletingCentro) return
    try {
      await fetch(`/api/centros-costo/${deletingCentro.id}`, { method: 'DELETE' })
      setDeleteDialogOpen(false)
      setDeletingCentro(null)
      fetchData()
    } catch (error) {
      console.error('Error deleting centro:', error)
    }
  }

  const getGastado = (centroId: string) => {
    return gastos
      .filter(g => g.centroCostoId === centroId)
      .reduce((sum, g) => sum + g.monto, 0)
  }

  const exportarCSV = () => {
    const headers = ['Codigo', 'Nombre', 'Descripcion', 'Responsable', 'TipoGasto', 'PresupuestoMensual', 'PresupuestoAnual', 'Estado']
    const rows = centros.map(c => [
      c.codigo,
      c.nombre,
      c.descripcion || '',
      c.responsable || '',
      c.tipoGasto,
      c.presupuestoMens,
      c.presupuestoAnual,
      c.estado
    ])
    const csv = [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n')
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `centros_costo_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  // Download template matching the Excel format
  const downloadTemplate = async () => {
    const templateData = [
      {
        Codigo: 'CC-001',
        Nombre: 'Mantención General',
        Descripcion: 'Mantenimiento preventivo y correctivo de instalaciones comunes',
        Responsable: 'Juan Pérez',
        TipoGasto: 'Variable',
        PresupuestoMensual: 3500000,
        PresupuestoAnual: 42000000,
        Estado: 'Activo'
      },
      {
        Codigo: 'CC-002',
        Nombre: 'Seguridad',
        Descripcion: 'Vigilancia, control de acceso y sistemas de seguridad',
        Responsable: 'Pedro González',
        TipoGasto: 'Contrato',
        PresupuestoMensual: 4500000,
        PresupuestoAnual: 54000000,
        Estado: 'Activo'
      }
    ]
    
    try {
      const XLSX = await import('xlsx')
      const ws = XLSX.utils.json_to_sheet(templateData)
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, ws, 'Centros de Costo')
      XLSX.writeFile(wb, 'plantilla_centros_costo.xlsx')
    } catch (error) {
      console.error('Error generating template:', error)
    }
  }

  // Handle file select
  const handleFileSelect = async (file: File) => {
    if (!file) return

    if (!file.name.match(/\.(xlsx|xls)$/i)) {
      return
    }

    setImportFile(file)

    try {
      const XLSX = await import('xlsx')
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data)
      const sheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[sheetName]
      const jsonData = XLSX.utils.sheet_to_json(worksheet) as Record<string, unknown>[]

      const previewRows: PreviewRow[] = []
      
      for (const row of jsonData) {
        // Map all fields from Excel
        const codigo = String(row.Codigo || row.codigo || row.CODIGO || '').trim()
        const nombre = String(row.Nombre || row.nombre || row.NOMBRE || '').trim()
        
        const mapped = {
          codigo: codigo || null,
          nombre: nombre || null,
          descripcion: String(row.Descripcion || row.descripcion || row.DESCRIPCION || row.Descripción || '').trim() || null,
          responsable: String(row.Responsable || row.responsable || row.RESPONSABLE || '').trim() || null,
          tipoGasto: normalizarTipoGasto(String(row.TipoGasto || row.tipoGasto || row.TIPOGASTO || row.tipo || 'Variable')),
          presupuestoMens: parseFloat(String(row.PresupuestoMensual || row.presupuestoMens || row.PresupuestoMens || row.presupuesto_mensual || '0')) || 0,
          presupuestoAnual: parseFloat(String(row.PresupuestoAnual || row.presupuestoAnual || row.PresupuestoAnual || row.presupuesto_anual || '0')) || 0,
          estado: normalizarEstado(String(row.Estado || row.estado || row.ESTADO || 'Activo')),
        }
        
        const errors: string[] = []
        if (!mapped.codigo) errors.push('Falta código')
        if (!mapped.nombre) errors.push('Falta nombre')
        
        let willCreate = true
        if (mapped.codigo) {
          const existente = centros.find(c => c.codigo.toLowerCase() === mapped.codigo!.toLowerCase())
          if (existente) willCreate = false
        }
        
        previewRows.push({
          original: row,
          mapped,
          valid: errors.length === 0,
          errors,
          willCreate
        })
      }
      
      setPreviewData(previewRows)
      setImportStep('preview')
      
    } catch (error) {
      console.error('Error processing file:', error)
    }
  }

  const normalizarEstado = (estado: string): string => {
    const lower = estado.toLowerCase().trim()
    if (lower.includes('activo') || lower.includes('active') || lower.includes('vigente')) return 'Activo'
    if (lower.includes('inactivo') || lower.includes('inactive') || lower.includes('pausado')) return 'Inactivo'
    if (lower.includes('cerrado') || lower.includes('closed') || lower.includes('finalizado')) return 'Cerrado'
    return estados.includes(estado) ? estado : 'Activo'
  }

  const normalizarTipoGasto = (tipo: string): string => {
    const lower = tipo.toLowerCase().trim()
    if (lower.includes('fijo') || lower.includes('fixed')) return 'Fijo'
    if (lower.includes('variable')) return 'Variable'
    if (lower.includes('contrato')) return 'Contrato'
    if (lower.includes('estacional') || lower.includes('seasonal')) return 'Estacional'
    if (lower.includes('reserva') || lower.includes('fondo')) return 'Fondo de Reserva'
    return tiposGasto.includes(tipo) ? tipo : 'Variable'
  }

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      await handleFileSelect(file)
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) {
      await handleFileSelect(file)
    }
  }, [centros])

  const executeImport = async () => {
    if (previewData.length === 0) return
    
    setImportStep('importing')
    
    try {
      const validRows = previewData.filter(r => r.valid).map(r => r.mapped)
      
      let creados = 0
      let actualizados = 0
      const errores: string[] = []
      
      for (const row of validRows) {
        try {
          const existente = centros.find(c => c.codigo.toLowerCase() === row.codigo!.toLowerCase())
          
          if (existente) {
            await fetch(`/api/centros-costo/${existente.id}`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                codigo: row.codigo,
                nombre: row.nombre,
                descripcion: row.descripcion,
                responsable: row.responsable,
                tipoGasto: row.tipoGasto,
                presupuestoMens: row.presupuestoMens,
                presupuestoAnual: row.presupuestoAnual,
                estado: row.estado,
              }),
            })
            actualizados++
          } else {
            await fetch('/api/centros-costo', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                codigo: row.codigo,
                nombre: row.nombre,
                descripcion: row.descripcion,
                responsable: row.responsable,
                tipoGasto: row.tipoGasto,
                presupuestoMens: row.presupuestoMens,
                presupuestoAnual: row.presupuestoAnual,
                estado: row.estado,
              }),
            })
            creados++
          }
        } catch (e) {
          errores.push(`Error con "${row.nombre}": ${e}`)
        }
      }
      
      setImportResult({ creados, actualizados, errores })
      setImportStep('result')
      fetchData()
      
    } catch (error) {
      console.error('Error importing:', error)
      setImportStep('preview')
    }
  }

  const resetImport = () => {
    setPreviewData([])
    setImportFile(null)
    setImportStep('upload')
    setImportResult(null)
  }

  // Calculate annual budget used (based on monthly)
  const handlePresupuestoMensChange = (value: number) => {
    setFormData({
      ...formData,
      presupuestoMens: value,
      presupuestoAnual: value * 12
    })
  }

  const totalPresupuestoMens = filteredCentros.reduce((sum, c) => sum + c.presupuestoMens, 0)
  const totalPresupuestoAnual = filteredCentros.reduce((sum, c) => sum + c.presupuestoAnual, 0)
  const totalGastado = filteredCentros.reduce((sum, c) => sum + getGastado(c.id), 0)

  // Mobile card view
  const renderMobileCard = (centro: CentroCosto) => {
    const gastado = getGastado(centro.id)
    const porcentaje = centro.presupuestoAnual > 0 ? Math.round((gastado / centro.presupuestoAnual) * 100) : 0
    
    return (
      <Card key={centro.id} className="mb-3">
        <CardContent className="p-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#0f2040] flex items-center justify-center shrink-0">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded">{centro.codigo}</span>
                <span className="font-semibold text-sm truncate">{centro.nombre}</span>
              </div>
              {centro.descripcion && (
                <p className="text-xs text-slate-500 mb-2 truncate">{centro.descripcion}</p>
              )}
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <Badge className={`${estadoColors[centro.estado] || ''} text-[9px]`}>
                  {centro.estado}
                </Badge>
                <Badge className={`${tipoGastoColors[centro.tipoGasto] || ''} text-[9px]`}>
                  {centro.tipoGasto}
                </Badge>
                {centro.responsable && (
                  <span className="text-[10px] text-slate-500">{centro.responsable}</span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs mb-2">
                <div>
                  <span className="text-slate-500 block">Presup. Mensual</span>
                  <span className="font-semibold">{formatCLP(centro.presupuestoMens)}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Presup. Anual</span>
                  <span className="font-semibold">{formatCLP(centro.presupuestoAnual)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Progress 
                  value={porcentaje} 
                  className={`h-1.5 flex-1 ${porcentaje > 90 ? '[&>div]:bg-red-500' : porcentaje > 70 ? '[&>div]:bg-amber-500' : ''}`}
                />
                <span className="text-[10px] text-slate-500">{porcentaje}%</span>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openDialog(centro)}>
                <Pencil className="w-4 h-4" />
              </Button>
              <Button size="icon" variant="ghost" className="h-8 w-8 text-red-600" onClick={() => openDeleteDialog(centro)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Stats Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <Card className="p-3">
          <div className="text-[10px] text-slate-500 font-semibold uppercase">Total Centros</div>
          <div className="text-xl font-bold text-[#0f2040]">{centros.length}</div>
        </Card>
        <Card className="p-3">
          <div className="text-[10px] text-slate-500 font-semibold uppercase">Presup. Mensual</div>
          <div className="text-xl font-bold text-[#0f2040]">{formatCLP(totalPresupuestoMens)}</div>
        </Card>
        <Card className="p-3">
          <div className="text-[10px] text-slate-500 font-semibold uppercase">Presup. Anual</div>
          <div className="text-xl font-bold text-[#0f2040]">{formatCLP(totalPresupuestoAnual)}</div>
        </Card>
        <Card className="p-3">
          <div className="text-[10px] text-slate-500 font-semibold uppercase">Gastado</div>
          <div className="text-xl font-bold text-red-600">{formatCLP(totalGastado)}</div>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 max-w-xs min-w-[140px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Buscar por código, nombre..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-9"
          />
        </div>
        <Select value={filterEstado} onValueChange={setFilterEstado}>
          <SelectTrigger className="w-28 h-9">
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Estado</SelectItem>
            {estados.map(e => (
              <SelectItem key={e} value={e}>{e}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterTipo} onValueChange={setFilterTipo}>
          <SelectTrigger className="w-28 h-9">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Tipo</SelectItem>
            {tiposGasto.map(t => (
              <SelectItem key={t} value={t}>{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" className="h-9" onClick={exportarCSV}>
          <Download className="w-4 h-4 sm:mr-2" />
          <span className="hidden sm:inline">Exportar</span>
        </Button>
        <Button variant="outline" size="sm" className="h-9" onClick={() => { resetImport(); setImportDialogOpen(true); }}>
          <Upload className="w-4 h-4 sm:mr-2" />
          <span className="hidden sm:inline">Importar</span>
        </Button>
        <Button size="sm" className="h-9" onClick={() => openDialog()}>
          <Plus className="w-4 h-4 sm:mr-2" />
          <span className="hidden sm:inline">Nuevo</span>
        </Button>
      </div>

      {/* Mobile Cards or Desktop Table */}
      {isMobile ? (
        <div className="space-y-2">
          {loading ? (
            <div className="p-8 text-center text-slate-400 text-sm">Cargando...</div>
          ) : filteredCentros.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm">Sin centros de costo</div>
          ) : (
            filteredCentros.map(renderMobileCard)
          )}
        </div>
      ) : (
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-sm">Centros de Costo ({filteredCentros.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-slate-50">
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Código</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Nombre</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Responsable</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Tipo</th>
                    <th className="text-right p-3 text-[10px] font-bold text-slate-500 uppercase">Presup. Mensual</th>
                    <th className="text-right p-3 text-[10px] font-bold text-slate-500 uppercase">Presup. Anual</th>
                    <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Estado</th>
                    <th className="text-center p-3 text-[10px] font-bold text-slate-500 uppercase">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={8} className="p-8 text-center text-slate-400">Cargando...</td></tr>
                  ) : filteredCentros.length === 0 ? (
                    <tr><td colSpan={8} className="p-8 text-center text-slate-400">Sin centros de costo</td></tr>
                  ) : (
                    filteredCentros.map((centro) => (
                      <tr key={centro.id} className="border-b last:border-0 hover:bg-slate-50">
                        <td className="p-3 font-mono text-xs font-semibold text-[#0f2040]">{centro.codigo}</td>
                        <td className="p-3">
                          <div className="font-semibold">{centro.nombre}</div>
                          {centro.descripcion && (
                            <div className="text-xs text-slate-500 truncate max-w-[200px]">{centro.descripcion}</div>
                          )}
                        </td>
                        <td className="p-3 text-xs">{centro.responsable || '–'}</td>
                        <td className="p-3">
                          <Badge className={`${tipoGastoColors[centro.tipoGasto] || ''} text-[9px]`}>
                            {centro.tipoGasto}
                          </Badge>
                        </td>
                        <td className="p-3 text-right font-mono text-xs">{formatCLP(centro.presupuestoMens)}</td>
                        <td className="p-3 text-right font-mono text-xs font-semibold">{formatCLP(centro.presupuestoAnual)}</td>
                        <td className="p-3">
                          <Badge className={estadoColors[centro.estado] || 'bg-slate-100'}>{centro.estado}</Badge>
                        </td>
                        <td className="p-3">
                          <div className="flex justify-center gap-1">
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openDialog(centro)}>
                              <Pencil className="w-3.5 h-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7 text-red-600 hover:text-red-700" onClick={() => openDeleteDialog(centro)}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base">{editingCentro ? 'Editar' : 'Nuevo'} Centro de Costo</DialogTitle>
          </DialogHeader>
          <div className="grid gap-3 py-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Código *</Label>
                <Input value={formData.codigo} onChange={(e) => setFormData({...formData, codigo: e.target.value})} placeholder="CC-001" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Nombre *</Label>
                <Input value={formData.nombre} onChange={(e) => setFormData({...formData, nombre: e.target.value})} placeholder="Nombre del centro" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Descripción</Label>
              <Input value={formData.descripcion} onChange={(e) => setFormData({...formData, descripcion: e.target.value})} placeholder="Descripción opcional" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Responsable</Label>
                <Input value={formData.responsable} onChange={(e) => setFormData({...formData, responsable: e.target.value})} placeholder="Nombre del responsable" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Tipo de Gasto</Label>
                <Select value={formData.tipoGasto} onValueChange={(v) => setFormData({...formData, tipoGasto: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {tiposGasto.map(t => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Presupuesto Mensual ($)</Label>
                <Input 
                  type="number" 
                  value={formData.presupuestoMens} 
                  onChange={(e) => handlePresupuestoMensChange(parseFloat(e.target.value) || 0)} 
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Presupuesto Anual ($)</Label>
                <Input 
                  type="number" 
                  value={formData.presupuestoAnual} 
                  onChange={(e) => setFormData({...formData, presupuestoAnual: parseFloat(e.target.value) || 0})} 
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Estado</Label>
              <Select value={formData.estado} onValueChange={(v) => setFormData({...formData, estado: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {estados.map(s => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button size="sm" onClick={handleSave} disabled={!formData.nombre.trim() || !formData.codigo.trim()}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar centro de costo?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Se eliminará permanentemente{deletingCentro && <strong> {deletingCentro.codigo} - {deletingCentro.nombre}</strong>}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Import Dialog */}
      <Dialog open={importDialogOpen} onOpenChange={(open) => { setImportDialogOpen(open); if (!open) resetImport(); }}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-base flex items-center gap-2">
              <FileUp className="w-5 h-5" />
              Importar Centros de Costo
            </DialogTitle>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto py-3">
            {/* Step: Upload */}
            {importStep === 'upload' && (
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg text-xs">
                  <p className="font-semibold text-blue-700 mb-2">📋 Formato aceptado:</p>
                  <ul className="text-blue-600 space-y-1">
                    <li>• <strong>Excel:</strong> .xlsx, .xls (requerido)</li>
                  </ul>
                </div>
                
                {/* Drag & Drop Zone */}
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={cn(
                    "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200",
                    isDragging 
                      ? "border-amber-400 bg-amber-50" 
                      : "border-slate-300 hover:border-amber-400 hover:bg-slate-50"
                  )}
                >
                  <input
                    type="file"
                    accept=".xlsx,.xls"
                    ref={fileInputRef}
                    onChange={handleImport}
                    className="hidden"
                  />
                  <div className="flex flex-col items-center gap-3">
                    <div className={cn(
                      "w-16 h-16 rounded-full flex items-center justify-center transition-colors",
                      isDragging ? "bg-amber-100" : "bg-slate-100"
                    )}>
                      <Upload className={cn(
                        "w-8 h-8",
                        isDragging ? "text-amber-500" : "text-slate-400"
                      )} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">
                        {isDragging ? 'Suelta el archivo aquí' : 'Arrastra y suelta tu archivo'}
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        o haz clic para seleccionar
                      </p>
                    </div>
                  </div>
                </div>
                
                {/* Download Template */}
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div className="text-xs">
                    <p className="font-semibold">¿No tienes un archivo preparado?</p>
                    <p className="text-slate-500">Descarga nuestra plantilla</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={downloadTemplate}>
                    <Download className="w-4 h-4 mr-2" />
                    Plantilla
                  </Button>
                </div>
                
                {/* Column reference */}
                <div className="bg-slate-50 p-3 rounded-lg text-xs">
                  <p className="font-semibold mb-2">📌 Columnas reconocidas:</p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-slate-600">
                    <div><strong>Codigo*:</strong> Identificador único</div>
                    <div><strong>Nombre*:</strong> Nombre del centro</div>
                    <div><strong>Descripcion:</strong> Descripción</div>
                    <div><strong>Responsable:</strong> Persona encargada</div>
                    <div><strong>TipoGasto:</strong> Fijo/Variable/Contrato/Estacional/Fondo de Reserva</div>
                    <div><strong>PresupuestoMensual:</strong> Monto mensual CLP</div>
                    <div><strong>PresupuestoAnual:</strong> Monto anual CLP</div>
                    <div><strong>Estado:</strong> Activo/Inactivo/Cerrado</div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Step: Preview */}
            {importStep === 'preview' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center gap-2 text-green-700">
                    <CheckCircle className="w-5 h-5" />
                    <div>
                      <p className="font-semibold text-sm">{importFile?.name}</p>
                      <p className="text-xs">{previewData.length} registros encontrados</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={resetImport}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                
                {/* Summary */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {previewData.filter(r => r.valid && r.willCreate).length}
                    </div>
                    <div className="text-xs text-green-600">Nuevos</div>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {previewData.filter(r => r.valid && !r.willCreate).length}
                    </div>
                    <div className="text-xs text-blue-600">Actualizar</div>
                  </div>
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {previewData.filter(r => !r.valid).length}
                    </div>
                    <div className="text-xs text-red-600">Con error</div>
                  </div>
                </div>
                
                {/* Preview Table */}
                <div className="border rounded-lg overflow-hidden">
                  <div className="max-h-64 overflow-y-auto">
                    <table className="w-full text-xs">
                      <thead className="sticky top-0 bg-slate-100">
                        <tr>
                          <th className="p-2 text-left font-semibold">#</th>
                          <th className="p-2 text-left font-semibold">Código</th>
                          <th className="p-2 text-left font-semibold">Nombre</th>
                          <th className="p-2 text-left font-semibold">Tipo</th>
                          <th className="p-2 text-right font-semibold">Presup. Mensual</th>
                          <th className="p-2 text-right font-semibold">Presup. Anual</th>
                          <th className="p-2 text-center font-semibold">Estado</th>
                          <th className="p-2 text-center font-semibold">Acción</th>
                        </tr>
                      </thead>
                      <tbody>
                        {previewData.map((row, idx) => (
                          <tr 
                            key={idx} 
                            className={cn(
                              "border-t",
                              !row.valid && "bg-red-50",
                              row.valid && row.willCreate && "bg-green-50/50",
                              row.valid && !row.willCreate && "bg-blue-50/50"
                            )}
                          >
                            <td className="p-2 text-slate-500">{idx + 1}</td>
                            <td className="p-2 font-mono">
                              {row.mapped.codigo || <span className="text-red-500">Sin código</span>}
                            </td>
                            <td className="p-2 font-medium">
                              {row.mapped.nombre || <span className="text-red-500">Sin nombre</span>}
                            </td>
                            <td className="p-2">
                              <Badge className={`${tipoGastoColors[row.mapped.tipoGasto] || ''} text-[9px]`}>
                                {row.mapped.tipoGasto}
                              </Badge>
                            </td>
                            <td className="p-2 text-right font-mono">{formatCLP(row.mapped.presupuestoMens)}</td>
                            <td className="p-2 text-right font-mono">{formatCLP(row.mapped.presupuestoAnual)}</td>
                            <td className="p-2 text-center">
                              <Badge className={`${estadoColors[row.mapped.estado] || ''} text-[9px]`}>
                                {row.mapped.estado}
                              </Badge>
                            </td>
                            <td className="p-2 text-center">
                              {row.valid ? (
                                row.willCreate ? (
                                  <Badge className="bg-green-100 text-green-700 text-[9px]">Crear</Badge>
                                ) : (
                                  <Badge className="bg-blue-100 text-blue-700 text-[9px]">Actualizar</Badge>
                                )
                              ) : (
                                <Badge className="bg-red-100 text-red-700 text-[9px]">Error</Badge>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                
                {previewData.some(r => !r.valid) && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="font-semibold text-red-700 text-xs mb-2">⚠️ Filas con errores:</p>
                    <ul className="text-xs text-red-600 space-y-1">
                      {previewData.filter(r => !r.valid).map((r, i) => (
                        <li key={i}>Fila {previewData.indexOf(r) + 1}: {r.errors.join(', ')}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
            
            {/* Step: Importing */}
            {importStep === 'importing' && (
              <div className="py-12 text-center">
                <Loader2 className="w-12 h-12 animate-spin text-amber-500 mx-auto mb-4" />
                <p className="font-semibold">Importando centros de costo...</p>
                <p className="text-xs text-slate-500 mt-1">Por favor espere</p>
              </div>
            )}
            
            {/* Step: Result */}
            {importStep === 'result' && importResult && (
              <div className="space-y-4">
                <div className="text-center py-6">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-500" />
                  </div>
                  <p className="font-semibold text-lg">¡Importación completada!</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-center">
                    <div className="text-3xl font-bold text-green-600">{importResult.creados}</div>
                    <div className="text-sm text-green-600">Centros creados</div>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-center">
                    <div className="text-3xl font-bold text-blue-600">{importResult.actualizados}</div>
                    <div className="text-sm text-blue-600">Centros actualizados</div>
                  </div>
                </div>
                
                {importResult.errores && importResult.errores.length > 0 && (
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="font-semibold text-yellow-700 text-xs mb-2">⚠️ Advertencias:</p>
                    <ul className="text-xs text-yellow-600 space-y-1">
                      {importResult.errores.map((e, i) => <li key={i}>{e}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
          
          <DialogFooter className="border-t pt-3">
            {importStep === 'upload' && (
              <Button variant="outline" size="sm" onClick={() => setImportDialogOpen(false)}>
                Cancelar
              </Button>
            )}
            {importStep === 'preview' && (
              <>
                <Button variant="outline" size="sm" onClick={resetImport}>
                  <X className="w-4 h-4 mr-2" />
                  Cancelar
                </Button>
                <Button 
                  size="sm" 
                  onClick={executeImport}
                  disabled={previewData.filter(r => r.valid).length === 0}
                >
                  <Check className="w-4 h-4 mr-2" />
                  Importar {previewData.filter(r => r.valid).length} registros
                </Button>
              </>
            )}
            {importStep === 'result' && (
              <Button size="sm" onClick={() => { setImportDialogOpen(false); resetImport(); }}>
                Cerrar
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
