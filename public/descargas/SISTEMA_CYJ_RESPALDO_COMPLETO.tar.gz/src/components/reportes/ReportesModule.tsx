'use client'

import { useState, useEffect } from 'react'
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Checkbox } from '@/components/ui/checkbox'
import {
  FileText, Download, Printer, Filter, Eye, Building2,
  Users, Wrench, Package, Receipt, DollarSign, AlertTriangle,
  ClipboardCheck, Scale, User, PiggyBank, CheckCircle,
  FileSpreadsheet, Search, RefreshCw, Calendar, QrCode
} from 'lucide-react'
import { toast } from 'sonner'

// Configuración de módulos para reportes
const MODULOS_CONFIG = {
  residentes: {
    label: 'Residentes',
    icon: Users,
    color: 'bg-green-500',
    filtros: ['estado', 'tipo'],
    opciones: { 
      estado: ['Activo', 'Moroso', 'Inactivo'],
      tipo: ['Residente', 'Propietario', 'Arrendatario', 'Visita']
    }
  },
  personal: {
    label: 'Personal',
    icon: User,
    color: 'bg-purple-500',
    filtros: ['estado', 'contrato'],
    opciones: { 
      estado: ['Activo', 'Vacaciones', 'Licencia', 'Inactivo'],
      contrato: ['Indefinido', 'Plazo Fijo', 'Por Obra', 'Part-Time']
    }
  },
  ot: {
    label: 'Órdenes de Trabajo',
    icon: Wrench,
    color: 'bg-orange-500',
    filtros: ['estado', 'tipo', 'prioridad'],
    opciones: {
      estado: ['Pendiente', 'En Progreso', 'Completado', 'Cancelado'],
      tipo: ['Correctivo', 'Preventivo', 'Mejora', 'Emergencia'],
      prioridad: ['Urgente', 'Alta', 'Media', 'Baja']
    }
  },
  proyectos: {
    label: 'Proyectos',
    icon: Wrench,
    color: 'bg-indigo-500',
    filtros: ['estado', 'categoria'],
    opciones: {
      estado: ['Planificado', 'En Ejecución', 'Completado', 'Cancelado', 'Pausado'],
      categoria: ['Áreas Verdes', 'Eléctrico', 'Sanitario', 'Infraestructura', 'Seguridad']
    }
  },
  gastos: {
    label: 'Gastos',
    icon: Receipt,
    color: 'bg-red-500',
    filtros: ['estado', 'categoria'],
    opciones: {
      estado: ['Pendiente', 'Pagado', 'Rechazado', 'En revisión'],
      categoria: ['Mantenimiento', 'Administración', 'Seguridad', 'Áreas Verdes', 'Servicios']
    }
  },
  gastoscomunes: {
    label: 'Gastos Comunes',
    icon: DollarSign,
    color: 'bg-emerald-500',
    filtros: ['estado'],
    opciones: { estado: ['Pendiente', 'Pagado', 'Vencido', 'Parcial'] }
  },
  morosidad: {
    label: 'Morosidad',
    icon: AlertTriangle,
    color: 'bg-red-600',
    filtros: ['estado'],
    opciones: { estado: ['Pendiente', 'Parcial', 'Pagado'] }
  },
  activos: {
    label: 'Activos',
    icon: Package,
    color: 'bg-indigo-500',
    filtros: ['estado', 'categoria'],
    opciones: {
      estado: ['Activo', 'Inactivo', 'En Reparación', 'Dado de Baja'],
      categoria: ['Equipo', 'Herramienta', 'Vehículo', 'Mobiliario', 'Infraestructura', 'Tecnología']
    }
  },
  inventario: {
    label: 'Inventario',
    icon: Package,
    color: 'bg-teal-500',
    filtros: ['categoria'],
    opciones: {
      categoria: ['Eléctrico', 'Fontanería', 'Ferretería', 'Pintura', 'Jardinería', 'Limpieza', 'Seguridad']
    }
  },
  materiales: {
    label: 'Materiales',
    icon: Package,
    color: 'bg-cyan-500',
    filtros: ['categoria'],
    opciones: {
      categoria: ['Eléctrico', 'Fontanería', 'Ferretería', 'Pintura', 'Jardinería', 'Limpieza', 'Seguridad']
    }
  },
  herramientas: {
    label: 'Herramientas',
    icon: Wrench,
    color: 'bg-slate-500',
    filtros: ['estado'],
    opciones: { estado: ['Bueno', 'Regular', 'Malo', 'En reparación'] }
  },
  tareas: {
    label: 'Tareas',
    icon: Wrench,
    color: 'bg-amber-500',
    filtros: ['categoria', 'frecuencia'],
    opciones: {
      categoria: ['Eléctrico', 'Hidráulico', 'Ascensores', 'Gas', 'Climatización', 'Seguridad', 'Infraestructura', 'Áreas Verdes'],
      frecuencia: ['Diaria', 'Semanal', 'Mensual', 'Trimestral', 'Semestral', 'Anual']
    }
  },
  proveedores: {
    label: 'Proveedores',
    icon: Building2,
    color: 'bg-cyan-500',
    filtros: ['estado'],
    opciones: { estado: ['Activo', 'Inactivo', 'En revisión'] }
  },
  reservas: {
    label: 'Reservas',
    icon: Calendar,
    color: 'bg-pink-500',
    filtros: ['estado', 'espacio'],
    opciones: {
      estado: ['Pendiente', 'Confirmada', 'Cancelada', 'Completada'],
      espacio: ['Quincho', 'Sala de Eventos', 'Piscina', 'Estacionamiento', 'Cancha Deportiva', 'Gimnasio']
    }
  },
  asistencia: {
    label: 'Asistencia',
    icon: Calendar,
    color: 'bg-blue-500',
    filtros: ['estado'],
    opciones: { estado: ['Pendiente', 'Presente', 'Ausente', 'Tarde', 'Permiso'] }
  },
  cumplimiento: {
    label: 'Cumplimiento Legal',
    icon: Scale,
    color: 'bg-slate-500',
    filtros: ['estado', 'categoria'],
    opciones: {
      estado: ['Pendiente', 'En Proceso', 'Completado', 'Vencido'],
      categoria: ['Legal', 'Seguridad', 'Reglamentario', 'Interno', 'Financiero']
    }
  },
  auditoria: {
    label: 'Auditoría',
    icon: ClipboardCheck,
    color: 'bg-amber-500',
    filtros: ['estado', 'tipo'],
    opciones: {
      estado: ['Planificada', 'En Ejecución', 'Completada', 'Cancelada'],
      tipo: ['Interna', 'Externa', 'Legal', 'Financiera', 'Operacional']
    }
  },
  rondas: {
    label: 'Rondas',
    icon: QrCode,
    color: 'bg-violet-500',
    filtros: ['estado'],
    opciones: { estado: ['Normal', 'Incidencia', 'Alerta'] }
  },
  centrocostos: {
    label: 'Centro de Costos',
    icon: PiggyBank,
    color: 'bg-teal-500',
    filtros: ['estado', 'tipoGasto'],
    opciones: {
      estado: ['Activo', 'Inactivo'],
      tipoGasto: ['Fijo', 'Variable', 'Contrato', 'Estacional', 'Fondo de Reserva']
    }
  }
}

interface FiltroState {
  fechaDesde: string
  fechaHasta: string
  [key: string]: string
}

interface ColumnConfig {
  key: string
  label: string
  visible: boolean
}

export function ReportesModule() {
  const [moduloSeleccionado, setModuloSeleccionado] = useState<string>('residentes')
  const [filtros, setFiltros] = useState<FiltroState>({
    fechaDesde: '',
    fechaHasta: ''
  })
  const [datos, setDatos] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [previewOpen, setPreviewOpen] = useState(false)
  const [columnas, setColumnas] = useState<ColumnConfig[]>([])
  
  // Cargar datos cuando cambie el módulo
  const fetchDatos = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.append('modulo', moduloSeleccionado)
      
      Object.entries(filtros).forEach(([key, value]) => {
        if (value) params.append(key, value)
      })
      
      const response = await fetch(`/api/reportes?${params.toString()}`)
      if (response.ok) {
        const data = await response.json()
        setDatos(data)
        
        // Generar columnas automáticamente
        if (data.length > 0) {
          const cols = Object.keys(data[0])
            .filter(k => !['id', 'createdAt', 'updatedAt', 'condominioId'].includes(k))
            .map(k => ({
              key: k,
              label: formatLabel(k),
              visible: true
            }))
          setColumnas(cols)
        } else {
          setColumnas([])
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error)
      toast.error('Error al cargar los datos')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchDatos()
  }, [moduloSeleccionado])

  const formatLabel = (key: string): string => {
    return key
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase())
      .trim()
  }

  const formatValue = (value: any, key: string): string => {
    if (value === null || value === undefined) return '-'
    if (typeof value === 'boolean') return value ? 'Sí' : 'No'
    if (key.toLowerCase().includes('fecha') || key.toLowerCase().includes('date')) {
      try {
        return new Date(value).toLocaleDateString('es-CL')
      } catch { return value }
    }
    if (key.toLowerCase().includes('monto') || key.toLowerCase().includes('precio') || 
        key.toLowerCase().includes('sueldo') || key.toLowerCase().includes('costo') ||
        key.toLowerCase().includes('total')) {
      return '$' + new Intl.NumberFormat('es-CL').format(Math.round(value || 0))
    }
    return String(value)
  }

  // Exportar a CSV
  const exportCSV = () => {
    if (datos.length === 0) return
    
    const cols = columnas.filter(c => c.visible)
    const headers = cols.map(c => c.label).join(',')
    
    const rows = datos.map(item => 
      cols.map(col => {
        let val = formatValue(item[col.key], col.key)
        // Escapar comas y comillas
        if (val.includes(',') || val.includes('"')) {
          val = `"${val.replace(/"/g, '""')}"`
        }
        return val
      }).join(',')
    ).join('\n')
    
    const csv = headers + '\n' + rows
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `reporte_${moduloSeleccionado}_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('CSV exportado correctamente')
  }

  // Exportar a PDF (HTML para imprimir)
  const exportPDF = () => {
    if (datos.length === 0) return
    
    const cols = columnas.filter(c => c.visible)
    const moduloConfig = MODULOS_CONFIG[moduloSeleccionado as keyof typeof MODULOS_CONFIG]
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Reporte - ${moduloConfig?.label || moduloSeleccionado}</title>
        <style>
          * { box-sizing: border-box; margin: 0; padding: 0; }
          body { font-family: Arial, sans-serif; font-size: 10px; padding: 20px; color: #000; }
          h1 { color: #0f2040; font-size: 14px; margin-bottom: 5px; }
          .header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; border-bottom: 3px solid #f0a500; padding-bottom: 12px; }
          .logo { width: 40px; height: 40px; background: #0f2040; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; font-size: 18px; }
          .subtitle { font-size: 11px; color: #64748b; }
          .filters { background: #f8fafc; padding: 8px 12px; margin-bottom: 12px; border-radius: 4px; font-size: 9px; }
          table { width: 100%; border-collapse: collapse; }
          th { background: #0f2040; color: white; padding: 6px 8px; font-size: 9px; text-align: left; font-weight: bold; }
          td { padding: 5px 8px; border-bottom: 1px solid #e8ecf0; font-size: 9px; }
          tr:nth-child(even) td { background: #f8fafc; }
          .footer { margin-top: 12px; font-size: 8px; color: #94a3b8; text-align: center; }
          .total-row td { font-weight: bold; background: #fef3c7 !important; }
          @media print { body { padding: 10px; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo">🏘️</div>
          <div>
            <h1>Asesorías Integrales CyJ</h1>
            <p class="subtitle">Reporte de ${moduloConfig?.label || moduloSeleccionado} – Generado el ${new Date().toLocaleDateString('es-CL')}</p>
          </div>
        </div>
        
        ${Object.values(filtros).some(v => v) ? `
        <div class="filters">
          <strong>Filtros aplicados:</strong>
          ${filtros.fechaDesde ? ` Desde: ${filtros.fechaDesde}` : ''}
          ${filtros.fechaHasta ? ` Hasta: ${filtros.fechaHasta}` : ''}
          ${Object.entries(filtros).filter(([k, v]) => v && !['fechaDesde', 'fechaHasta'].includes(k)).map(([k, v]) => `${formatLabel(k)}: ${v}`).join(' | ')}
        </div>
        ` : ''}
        
        <table>
          <thead>
            <tr>
              <th>#</th>
              ${cols.map(c => `<th>${c.label}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${datos.map((item, i) => `
              <tr>
                <td>${i + 1}</td>
                ${cols.map(col => `<td>${formatValue(item[col.key], col.key)}</td>`).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div class="footer">
          Total de registros: ${datos.length} | Generado: ${new Date().toLocaleString('es-CL')}
        </div>
      </body>
      </html>
    `
    
    const w = window.open('', '_blank', 'width=960,height=720')
    if (w) {
      w.document.open()
      w.document.write(html)
      w.document.close()
      w.onload = () => setTimeout(() => w.print(), 400)
    }
  }

  // Obtener totales para columnas numéricas
  const getTotales = () => {
    const totales: Record<string, number> = {}
    columnas.forEach(col => {
      if (col.key.toLowerCase().includes('monto') || col.key.toLowerCase().includes('precio') ||
          col.key.toLowerCase().includes('sueldo') || col.key.toLowerCase().includes('costo') ||
          col.key.toLowerCase().includes('total')) {
        totales[col.key] = datos.reduce((sum, item) => sum + (Number(item[col.key]) || 0), 0)
      }
    })
    return totales
  }

  const totales = getTotales()
  const moduloConfig = MODULOS_CONFIG[moduloSeleccionado as keyof typeof MODULOS_CONFIG]

  return (
    <div className="space-y-6">
      {/* Selector de módulo */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Generador de Reportes
          </CardTitle>
          <CardDescription>
            Seleccione el módulo y aplique filtros para generar reportes personalizados
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {Object.entries(MODULOS_CONFIG).map(([key, config]) => (
              <button
                key={key}
                onClick={() => setModuloSeleccionado(key)}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  moduloSeleccionado === key 
                    ? 'border-amber-500 bg-amber-50' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <config.icon className={`w-6 h-6 mx-auto mb-1 ${config.color.replace('bg-', 'text-')}`} />
                <span className="text-xs font-medium">{config.label}</span>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {/* Filtros de fecha */}
            <div>
              <Label className="text-xs">Fecha Desde</Label>
              <Input
                type="date"
                value={filtros.fechaDesde}
                onChange={(e) => setFiltros({ ...filtros, fechaDesde: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Fecha Hasta</Label>
              <Input
                type="date"
                value={filtros.fechaHasta}
                onChange={(e) => setFiltros({ ...filtros, fechaHasta: e.target.value })}
              />
            </div>
            
            {/* Filtros específicos del módulo */}
            {moduloConfig?.filtros.map((filtro) => (
              <div key={filtro}>
                <Label className="text-xs">{formatLabel(filtro)}</Label>
                <Select
                  value={filtros[filtro] || 'todos'}
                  onValueChange={(v) => setFiltros({ ...filtros, [filtro]: v === 'todos' ? '' : v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    {(moduloConfig.opciones[filtro] || []).map((op: string) => (
                      <SelectItem key={op} value={op}>{op}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ))}
            
            {/* Botones de acción */}
            <div className="flex items-end gap-2">
              <Button onClick={fetchDatos} disabled={loading}>
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setFiltros({ fechaDesde: '', fechaHasta: '' })}
              >
                Limpiar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Resultados y acciones */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <CardTitle className="text-base">
                {moduloConfig?.label || 'Resultados'}
              </CardTitle>
              <CardDescription>
                {datos.length} registros encontrados
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setPreviewOpen(true)} disabled={datos.length === 0}>
                <Eye className="w-4 h-4 mr-2" />
                Vista Previa
              </Button>
              <Button variant="outline" size="sm" onClick={exportCSV} disabled={datos.length === 0}>
                <FileSpreadsheet className="w-4 h-4 mr-2" />
                CSV
              </Button>
              <Button variant="outline" size="sm" onClick={exportPDF} disabled={datos.length === 0}>
                <Printer className="w-4 h-4 mr-2" />
                Imprimir/PDF
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <RefreshCw className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
              <p className="text-muted-foreground mt-2">Cargando datos...</p>
            </div>
          ) : datos.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No hay datos para mostrar</p>
              <p className="text-sm">Ajuste los filtros y busque nuevamente</p>
            </div>
          ) : (
            <div className="rounded-md border overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10">#</TableHead>
                    {columnas.filter(c => c.visible).map(col => (
                      <TableHead key={col.key}>{col.label}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {datos.slice(0, 100).map((item, i) => (
                    <TableRow key={item.id || i}>
                      <TableCell className="font-mono text-xs">{i + 1}</TableCell>
                      {columnas.filter(c => c.visible).map(col => (
                        <TableCell key={col.key}>
                          {formatValue(item[col.key], col.key)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
                {Object.keys(totales).length > 0 && (
                  <TableHeader>
                    <TableRow className="bg-amber-50">
                      <TableHead colSpan={1} className="font-bold">TOTALES</TableHead>
                      {columnas.filter(c => c.visible).map(col => (
                        <TableHead key={col.key} className="font-bold">
                          {totales[col.key] !== undefined ? formatValue(totales[col.key], col.key) : ''}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                )}
              </Table>
              {datos.length > 100 && (
                <div className="text-center py-2 text-sm text-muted-foreground bg-muted/50">
                  Mostrando 100 de {datos.length} registros. Use la exportación para ver todos.
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Selector de columnas */}
      {columnas.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Columnas visibles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              {columnas.map((col) => (
                <label key={col.key} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={col.visible}
                    onCheckedChange={(checked) => {
                      setColumnas(columnas.map(c => 
                        c.key === col.key ? { ...c, visible: !!checked } : c
                      ))
                    }}
                  />
                  {col.label}
                </label>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dialog de vista previa */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Vista Previa - {moduloConfig?.label}</DialogTitle>
            <DialogDescription>
              {datos.length} registros | {columnas.filter(c => c.visible).length} columnas
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[60vh]">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10">#</TableHead>
                    {columnas.filter(c => c.visible).map(col => (
                      <TableHead key={col.key}>{col.label}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {datos.map((item, i) => (
                    <TableRow key={item.id || i}>
                      <TableCell className="font-mono text-xs">{i + 1}</TableCell>
                      {columnas.filter(c => c.visible).map(col => (
                        <TableCell key={col.key}>
                          {formatValue(item[col.key], col.key)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </ScrollArea>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={exportCSV}>
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Exportar CSV
            </Button>
            <Button onClick={exportPDF}>
              <Printer className="w-4 h-4 mr-2" />
              Imprimir/PDF
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
