'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import {
  QrCode,
  Plus,
  Search,
  Download,
  Scan,
  MapPin,
  Clock,
  User,
  CheckCircle,
  AlertTriangle,
  Trash2,
  Eye
} from 'lucide-react'
import { toast } from 'sonner'
import QRCode from 'qrcode'

interface PuntoRonda {
  id: string
  nombre: string
  ubicacion: string
  descripcion?: string
  codigoQr: string
  activo: boolean
  orden: number
  createdAt: string
}

interface RegistroRonda {
  id: string
  puntoId: string
  punto?: PuntoRonda
  usuarioId?: string
  usuarioNombre?: string
  fechaHora: string
  ubicacion?: string
  observaciones?: string
  estado: string
  notaIncidencia?: string
}

export function RondasModule() {
  const [puntos, setPuntos] = useState<PuntoRonda[]>([])
  const [registros, setRegistros] = useState<RegistroRonda[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [qrDialogOpen, setQrDialogOpen] = useState(false)
  const [escanearDialogOpen, setEscanearDialogOpen] = useState(false)
  const [selectedPunto, setSelectedPunto] = useState<PuntoRonda | null>(null)
  const [qrCodeImage, setQrCodeImage] = useState('')
  const [qrInput, setQrInput] = useState('')
  const [activeTab, setActiveTab] = useState<'puntos' | 'registros'>('puntos')
  
  const [formData, setFormData] = useState({
    nombre: '',
    ubicacion: '',
    descripcion: '',
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [puntosRes, registrosRes] = await Promise.all([
        fetch('/api/rondas'),
        fetch('/api/rondas/registros'),
      ])
      
      if (puntosRes.ok) {
        const puntosData = await puntosRes.json()
        setPuntos(puntosData)
      }
      
      if (registrosRes.ok) {
        const registrosData = await registrosRes.json()
        setRegistros(registrosData)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
      toast.error('Error al cargar datos')
    } finally {
      setLoading(false)
    }
  }

  const generateQRCode = async (codigoQr: string) => {
    try {
      const qrDataUrl = await QRCode.toDataURL(codigoQr, {
        width: 300,
        margin: 2,
        color: {
          dark: '#0f2040',
          light: '#ffffff',
        },
      })
      setQrCodeImage(qrDataUrl)
    } catch (error) {
      console.error('Error generating QR:', error)
      toast.error('Error al generar código QR')
    }
  }

  const handleCreatePunto = async () => {
    if (!formData.nombre || !formData.ubicacion) {
      toast.error('Nombre y ubicación son requeridos')
      return
    }

    try {
      const response = await fetch('/api/rondas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        toast.success('Punto de ronda creado exitosamente')
        setDialogOpen(false)
        setFormData({ nombre: '', ubicacion: '', descripcion: '' })
        fetchData()
      } else {
        const error = await response.json()
        toast.error(error.error || 'Error al crear punto')
      }
    } catch (error) {
      toast.error('Error al crear punto de ronda')
    }
  }

  const handleDeletePunto = async (id: string) => {
    if (!confirm('¿Está seguro de eliminar este punto de ronda?')) return

    try {
      const response = await fetch(`/api/rondas/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        toast.success('Punto eliminado')
        fetchData()
      } else {
        toast.error('Error al eliminar punto')
      }
    } catch (error) {
      toast.error('Error al eliminar punto')
    }
  }

  const handleShowQR = async (punto: PuntoRonda) => {
    setSelectedPunto(punto)
    await generateQRCode(punto.codigoQr)
    setQrDialogOpen(true)
  }

  const handleEscanearQR = () => {
    if (!qrInput.trim()) {
      toast.error('Ingrese el código QR')
      return
    }

    // Buscar el punto por código QR
    const punto = puntos.find(p => p.codigoQr === qrInput.trim())
    
    if (punto) {
      // Registrar el escaneo
      registrarEscaneo(punto.id)
    } else {
      toast.error('Código QR no válido')
    }
  }

  const registrarEscaneo = async (puntoId: string) => {
    try {
      const response = await fetch('/api/rondas/escanear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          puntoId,
          observaciones: '',
        }),
      })

      if (response.ok) {
        toast.success('Ronda registrada exitosamente')
        setQrInput('')
        setEscanearDialogOpen(false)
        fetchData()
      } else {
        const error = await response.json()
        toast.error(error.error || 'Error al registrar ronda')
      }
    } catch (error) {
      toast.error('Error al registrar ronda')
    }
  }

  const downloadQR = () => {
    if (!qrCodeImage || !selectedPunto) return

    const link = document.createElement('a')
    link.href = qrCodeImage
    link.download = `qr-ronda-${selectedPunto.nombre.replace(/\s+/g, '-')}.png`
    link.click()
  }

  const exportToCSV = () => {
    const headers = ['Nombre', 'Ubicación', 'Código QR', 'Activo', 'Fecha Creación']
    const rows = puntos.map(p => [
      p.nombre,
      p.ubicacion,
      p.codigoQr,
      p.activo ? 'Sí' : 'No',
      new Date(p.createdAt).toLocaleDateString('es-CL'),
    ])

    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.map(c => `"${c}"`).join(',')),
    ].join('\n')

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `rondas-${new Date().toISOString().split('T')[0]}.csv`
    link.click()
  }

  const exportRegistrosCSV = () => {
    const headers = ['Punto', 'Usuario', 'Fecha/Hora', 'Estado', 'Observaciones']
    const rows = registros.map(r => [
      r.punto?.nombre || 'N/A',
      r.usuarioNombre || 'N/A',
      new Date(r.fechaHora).toLocaleString('es-CL'),
      r.estado,
      r.observaciones || '',
    ])

    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.map(c => `"${c}"`).join(',')),
    ].join('\n')

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `registros-rondas-${new Date().toISOString().split('T')[0]}.csv`
    link.click()
  }

  const filteredPuntos = puntos.filter(p =>
    p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.ubicacion.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const filteredRegistros = registros.filter(r =>
    r.punto?.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.usuarioNombre?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'Normal':
        return <Badge className="bg-green-100 text-green-800">Normal</Badge>
      case 'Incidencia':
        return <Badge className="bg-amber-100 text-amber-800">Incidencia</Badge>
      case 'Alerta':
        return <Badge className="bg-red-100 text-red-800">Alerta</Badge>
      default:
        return <Badge>{estado}</Badge>
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <MapPin className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Total Puntos</p>
                <p className="text-2xl font-bold">{puntos.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Puntos Activos</p>
                <p className="text-2xl font-bold">{puntos.filter(p => p.activo).length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-100 rounded-lg">
                <Scan className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Rondas Hoy</p>
                <p className="text-2xl font-bold">
                  {registros.filter(r => 
                    new Date(r.fechaHora).toDateString() === new Date().toDateString()
                  ).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Incidencias</p>
                <p className="text-2xl font-bold">
                  {registros.filter(r => r.estado === 'Incidencia' || r.estado === 'Alerta').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b">
        <button
          onClick={() => setActiveTab('puntos')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'puntos'
              ? 'border-b-2 border-blue-600 text-blue-600'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Puntos de Ronda
        </button>
        <button
          onClick={() => setActiveTab('registros')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'registros'
              ? 'border-b-2 border-blue-600 text-blue-600'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Registro de Rondas
        </button>
      </div>

      {/* Actions Bar */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Buscar..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          {activeTab === 'puntos' ? (
            <>
              <Button variant="outline" onClick={exportToCSV}>
                <Download className="w-4 h-4 mr-2" />
                Exportar CSV
              </Button>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Punto
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={exportRegistrosCSV}>
                <Download className="w-4 h-4 mr-2" />
                Exportar CSV
              </Button>
              <Button onClick={() => setEscanearDialogOpen(true)}>
                <Scan className="w-4 h-4 mr-2" />
                Registrar Ronda
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'puntos' ? (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Ubicación</TableHead>
                  <TableHead>Código QR</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Fecha Creación</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPuntos.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                      No hay puntos de ronda registrados
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredPuntos.map((punto) => (
                    <TableRow key={punto.id}>
                      <TableCell className="font-medium">{punto.nombre}</TableCell>
                      <TableCell>{punto.ubicacion}</TableCell>
                      <TableCell>
                        <code className="text-xs bg-slate-100 px-2 py-1 rounded">
                          {punto.codigoQr.substring(0, 12)}...
                        </code>
                      </TableCell>
                      <TableCell>
                        {punto.activo ? (
                          <Badge className="bg-green-100 text-green-800">Activo</Badge>
                        ) : (
                          <Badge className="bg-slate-100 text-slate-800">Inactivo</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {new Date(punto.createdAt).toLocaleDateString('es-CL')}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleShowQR(punto)}
                          >
                            <QrCode className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDeletePunto(punto.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Punto</TableHead>
                  <TableHead>Usuario</TableHead>
                  <TableHead>Fecha/Hora</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Observaciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRegistros.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-slate-500">
                      No hay registros de rondas
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRegistros.map((registro) => (
                    <TableRow key={registro.id}>
                      <TableCell className="font-medium">
                        {registro.punto?.nombre || 'N/A'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-slate-400" />
                          {registro.usuarioNombre || 'Sistema'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-slate-400" />
                          {new Date(registro.fechaHora).toLocaleString('es-CL')}
                        </div>
                      </TableCell>
                      <TableCell>{getEstadoBadge(registro.estado)}</TableCell>
                      <TableCell>{registro.observaciones || '-'}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Create Punto Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Crear Punto de Ronda</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label>Nombre *</Label>
              <Input
                value={formData.nombre}
                onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                placeholder="Ej: Portería Principal"
              />
            </div>
            <div>
              <Label>Ubicación *</Label>
              <Input
                value={formData.ubicacion}
                onChange={(e) => setFormData({ ...formData, ubicacion: e.target.value })}
                placeholder="Ej: Acceso Norte, Estacionamiento"
              />
            </div>
            <div>
              <Label>Descripción</Label>
              <Textarea
                value={formData.descripcion}
                onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })}
                placeholder="Notas adicionales..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreatePunto}>Crear Punto</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* QR Code Dialog */}
      <Dialog open={qrDialogOpen} onOpenChange={setQrDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Código QR - {selectedPunto?.nombre}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center py-4">
            {qrCodeImage && (
              <>
                <img src={qrCodeImage} alt="QR Code" className="mb-4 rounded-lg shadow" />
                <p className="text-sm text-slate-600 mb-2">{selectedPunto?.ubicacion}</p>
                <code className="text-xs bg-slate-100 px-3 py-1 rounded mb-4">
                  {selectedPunto?.codigoQr}
                </code>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setQrDialogOpen(false)}>
              Cerrar
            </Button>
            <Button onClick={downloadQR}>
              <Download className="w-4 h-4 mr-2" />
              Descargar QR
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Escanear QR Dialog */}
      <Dialog open={escanearDialogOpen} onOpenChange={setEscanearDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Registrar Ronda</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm text-slate-600">
              Ingrese el código QR del punto de ronda o escanee con una aplicación de QR.
            </p>
            <div>
              <Label>Código QR</Label>
              <Input
                value={qrInput}
                onChange={(e) => setQrInput(e.target.value)}
                placeholder="Pegue o escanee el código QR"
              />
            </div>
            {qrInput && puntos.find(p => p.codigoQr === qrInput.trim()) && (
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="font-medium text-green-800">
                  Punto encontrado: {puntos.find(p => p.codigoQr === qrInput.trim())?.nombre}
                </p>
                <p className="text-sm text-green-600">
                  {puntos.find(p => p.codigoQr === qrInput.trim())?.ubicacion}
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEscanearDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleEscanearQR}>
              <CheckCircle className="w-4 h-4 mr-2" />
              Registrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
