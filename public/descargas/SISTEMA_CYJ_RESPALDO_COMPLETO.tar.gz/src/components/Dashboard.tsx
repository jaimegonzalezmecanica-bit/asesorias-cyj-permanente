/**
 * Dashboard Component
 * CORREGIDO: Agregado manejo de errores robusto y validación de datos
 */

'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { AlertCircle, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'

// CORREGIDO: Tipado más estricto con valores opcionales
interface DashboardStats {
  totalPropiedades?: number
  totalResidentes?: number
  otPendientes?: number
  otEnProgreso?: number
  otCompletadas?: number
  morosos?: number
  totalPersonal?: number
  totalActivos?: number
  valorActivos?: number
  saldoCaja?: number
  saldoInicialCaja?: number
  totalGastado?: number
  gastosDelMes?: number
}

interface EstadoPropiedades {
  Ocupado?: number
  Disponible?: number
  Arriendo?: number
  Venta?: number
  Mantenimiento?: number
}

interface OrdenTrabajo {
  id: string
  otNum: string
  titulo: string
  prioridad: string
  estado: string
  fechaLimite: string | null
}

interface CentroCosto {
  id: string
  nombre: string
  presupuesto: number
  gastado: number
  porcentaje: number
}

interface DashboardData {
  stats: DashboardStats
  estadoPropiedades: EstadoPropiedades
  recentOT: OrdenTrabajo[]
  centrosConGasto: CentroCosto[]
}

// CORREGIDO: Estado de error separado
interface DashboardState {
  data: DashboardData | null
  loading: boolean
  error: string | null
}

// CORREGIDO: Funciones de formateo con valores por defecto seguros
const formatCLP = (n: number | undefined | null): string => {
  const value = n ?? 0
  return '$' + new Intl.NumberFormat('es-CL').format(Math.round(value))
}

const formatDate = (d: string | null | undefined): string => {
  if (!d) return '–'
  try {
    const [y, m, dd] = d.split('-')
    if (!y || !m || !dd) return '–'
    return `${dd}/${m}/${y}`
  } catch {
    return '–'
  }
}

const priorityColors: Record<string, string> = {
  'Urgente': 'bg-red-100 text-red-700',
  'Alta': 'bg-orange-100 text-orange-700',
  'Media': 'bg-yellow-100 text-yellow-700',
  'Baja': 'bg-green-100 text-green-700',
}

const estadoColors: Record<string, string> = {
  'Pendiente': 'bg-yellow-100 text-yellow-700',
  'En Progreso': 'bg-blue-100 text-blue-700',
  'Completado': 'bg-green-100 text-green-700',
  'Cancelado': 'bg-red-100 text-red-700',
}

// CORREGIDO: Valores por defecto para datos vacíos
const defaultStats: DashboardStats = {
  totalPropiedades: 0,
  totalResidentes: 0,
  otPendientes: 0,
  otEnProgreso: 0,
  otCompletadas: 0,
  morosos: 0,
  totalPersonal: 0,
  totalActivos: 0,
  valorActivos: 0,
  saldoCaja: 0,
  saldoInicialCaja: 0,
  totalGastado: 0,
  gastosDelMes: 0,
}

const defaultEstadoPropiedades: EstadoPropiedades = {
  Ocupado: 0,
  Disponible: 0,
  Arriendo: 0,
  Venta: 0,
  Mantenimiento: 0,
}

export function Dashboard() {
  // CORREGIDO: Estado consolidado con manejo de errores
  const [state, setState] = useState<DashboardState>({
    data: null,
    loading: true,
    error: null,
  })

  // CORREGIDO: Función de carga con manejo de errores completo
  const fetchDashboardData = async () => {
    setState(prev => ({ ...prev, loading: true, error: null }))

    try {
      const response = await fetch('/api/dashboard')

      // CORREGIDO: Verificar status HTTP
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('No autorizado. Por favor, inicie sesión.')
        }
        if (response.status === 403) {
          throw new Error('No tiene permisos para ver el dashboard.')
        }
        throw new Error(`Error del servidor: ${response.status}`)
      }

      const rawData = await response.json()

      // CORREGIDO: Validar estructura de datos
      const data: DashboardData = {
        stats: { ...defaultStats, ...rawData?.stats },
        estadoPropiedades: { ...defaultEstadoPropiedades, ...rawData?.estadoPropiedades },
        recentOT: Array.isArray(rawData?.recentOT) ? rawData.recentOT : [],
        centrosConGasto: Array.isArray(rawData?.centrosConGasto) ? rawData.centrosConGasto : [],
      }

      setState({ data, loading: false, error: null })
    } catch (error) {
      console.error('[Dashboard] Error fetching data:', error)

      // CORREGIDO: Mensaje de error descriptivo
      const errorMessage = error instanceof Error
        ? error.message
        : 'Error al cargar los datos del dashboard'

      setState({ data: null, loading: false, error: errorMessage })
    }
  }

  useEffect(() => {
    fetchDashboardData()
  }, [])

  // CORREGIDO: Estado de carga con skeleton
  if (state.loading) {
    return (
      <div className="space-y-4 sm:space-y-5">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-3 sm:p-4">
                <div className="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
                <div className="h-8 bg-slate-200 rounded w-3/4"></div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card className="lg:col-span-2 animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-slate-200 rounded w-1/4 mb-4"></div>
              <div className="space-y-2">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-8 bg-slate-200 rounded"></div>
                ))}
              </div>
            </CardContent>
          </Card>
          <Card className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-slate-200 rounded w-1/2 mb-4"></div>
              <div className="space-y-2">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-6 bg-slate-200 rounded"></div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // CORREGIDO: Estado de error con opción de reintentar
  if (state.error) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardContent className="p-6 text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-700 mb-2">Error al cargar dashboard</h3>
          <p className="text-red-600 mb-4">{state.error}</p>
          <Button
            onClick={fetchDashboardData}
            variant="outline"
            className="gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Reintentar
          </Button>
        </CardContent>
      </Card>
    )
  }

  // CORREGIDO: Verificar datos antes de renderizar
  if (!state.data) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-slate-500">
          No hay datos disponibles
        </CardContent>
      </Card>
    )
  }

  const { stats, estadoPropiedades, recentOT, centrosConGasto } = state.data

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-3 sm:p-4">
            <div className="text-xl sm:text-2xl mb-1">🏠</div>
            <div className="text-[9px] sm:text-[10px] text-slate-500 font-semibold uppercase tracking-wide">Unidades</div>
            <div className="text-xl sm:text-2xl font-bold text-[#0f2040]">{stats.totalPropiedades ?? 0}</div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-3 sm:p-4">
            <div className="text-xl sm:text-2xl mb-1">👥</div>
            <div className="text-[9px] sm:text-[10px] text-slate-500 font-semibold uppercase tracking-wide">Residentes</div>
            <div className="text-xl sm:text-2xl font-bold text-[#0f2040]">{stats.totalResidentes ?? 0}</div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-3 sm:p-4">
            <div className="text-xl sm:text-2xl mb-1">🔧</div>
            <div className="text-[9px] sm:text-[10px] text-slate-500 font-semibold uppercase tracking-wide">OT Pendientes</div>
            <div className="text-xl sm:text-2xl font-bold text-amber-600">{stats.otPendientes ?? 0}</div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-3 sm:p-4">
            <div className="text-xl sm:text-2xl mb-1">⚠️</div>
            <div className="text-[9px] sm:text-[10px] text-slate-500 font-semibold uppercase tracking-wide">Morosos</div>
            <div className="text-xl sm:text-2xl font-bold text-red-600">{stats.morosos ?? 0}</div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-3 sm:p-4">
            <div className="text-xl sm:text-2xl mb-1">👤</div>
            <div className="text-[9px] sm:text-[10px] text-slate-500 font-semibold uppercase tracking-wide">Personal</div>
            <div className="text-xl sm:text-2xl font-bold text-[#0f2040]">{stats.totalPersonal ?? 0}</div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-3 sm:p-4">
            <div className="text-xl sm:text-2xl mb-1">💰</div>
            <div className="text-[9px] sm:text-[10px] text-slate-500 font-semibold uppercase tracking-wide">Caja Chica</div>
            <div className="text-sm sm:text-base font-bold text-[#0f2040]">{formatCLP(stats.saldoCaja)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5">
        {/* OT Recientes */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2 sm:pb-3">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              🔧 OT Recientes
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-xs sm:text-sm">
                <thead>
                  <tr className="border-b bg-slate-50">
                    <th className="text-left p-2 sm:p-3 text-[9px] sm:text-[10px] font-bold text-slate-500 uppercase">N° OT</th>
                    <th className="text-left p-2 sm:p-3 text-[9px] sm:text-[10px] font-bold text-slate-500 uppercase">Título</th>
                    <th className="text-left p-2 sm:p-3 text-[9px] sm:text-[10px] font-bold text-slate-500 uppercase hidden sm:table-cell">Prioridad</th>
                    <th className="text-left p-2 sm:p-3 text-[9px] sm:text-[10px] font-bold text-slate-500 uppercase">Estado</th>
                    <th className="text-left p-2 sm:p-3 text-[9px] sm:text-[10px] font-bold text-slate-500 uppercase hidden md:table-cell">F. Límite</th>
                  </tr>
                </thead>
                <tbody>
                  {recentOT.length > 0 ? (
                    recentOT.map((ot) => (
                      <tr key={ot.id} className="border-b last:border-0 hover:bg-slate-50">
                        <td className="p-2 sm:p-3 font-mono text-[10px] sm:text-xs font-bold text-[#0f2040]">{ot.otNum || '–'}</td>
                        <td className="p-2 sm:p-3 font-medium truncate max-w-[120px] sm:max-w-none">{ot.titulo || 'Sin título'}</td>
                        <td className="p-2 sm:p-3 hidden sm:table-cell">
                          <Badge className={`${priorityColors[ot.prioridad] || 'bg-slate-100'} text-[9px] sm:text-[10px]`}>
                            {ot.prioridad || 'Sin prioridad'}
                          </Badge>
                        </td>
                        <td className="p-2 sm:p-3">
                          <Badge className={`${estadoColors[ot.estado] || 'bg-slate-100'} text-[9px] sm:text-[10px]`}>
                            {ot.estado || 'Sin estado'}
                          </Badge>
                        </td>
                        <td className="p-2 sm:p-3 text-[10px] sm:text-xs text-slate-600 hidden md:table-cell">{formatDate(ot.fechaLimite)}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} className="p-6 sm:p-8 text-center text-slate-400 text-xs sm:text-sm">
                        Sin órdenes de trabajo
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Right Side */}
        <div className="space-y-4 sm:space-y-5">
          {/* Estado Unidades */}
          <Card>
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                🏠 Estado Unidades
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1.5 sm:space-y-2">
              {Object.entries(estadoPropiedades).map(([estado, count]) =>
                (count ?? 0) > 0 && (
                  <div key={estado} className="flex items-center justify-between py-1 border-b last:border-0">
                    <Badge className={`text-[9px] sm:text-[10px] ${
                      estado === 'Ocupado' ? 'bg-red-100 text-red-700' :
                      estado === 'Disponible' ? 'bg-green-100 text-green-700' :
                      estado === 'Arriendo' ? 'bg-purple-100 text-purple-700' :
                      estado === 'Venta' ? 'bg-orange-100 text-orange-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {estado}
                    </Badge>
                    <span className="font-bold text-[#0f2040] text-sm sm:text-base">{count}</span>
                  </div>
                )
              )}
              {/* CORREGIDO: Mostrar mensaje si no hay propiedades */}
              {Object.values(estadoPropiedades).every(v => !v) && (
                <p className="text-center text-slate-400 text-xs py-2">Sin datos de propiedades</p>
              )}
            </CardContent>
          </Card>

          {/* Gastos del Mes */}
          <Card>
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                📈 Gastos del Mes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-lg sm:text-xl font-bold text-red-600">{formatCLP(stats.gastosDelMes)}</div>
              <div className="text-[10px] sm:text-xs text-slate-500 mt-1">Total gastado este mes</div>
            </CardContent>
          </Card>

          {/* Centro de Costos */}
          <Card>
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-sm font-bold">Centros de Costo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 sm:space-y-3">
              {centrosConGasto.length > 0 ? (
                centrosConGasto.slice(0, 4).map((cc) => (
                  <div key={cc.id} className="space-y-1">
                    <div className="flex justify-between text-[10px] sm:text-xs">
                      <span className="font-medium truncate max-w-[120px] sm:max-w-none">{cc.nombre || 'Sin nombre'}</span>
                      <span className={`${(cc.porcentaje ?? 0) > 90 ? 'text-red-600 font-bold' : 'text-slate-600'} ml-2 shrink-0`}>
                        {Math.round(cc.porcentaje ?? 0)}%
                      </span>
                    </div>
                    <Progress value={Math.min(100, Math.max(0, cc.porcentaje ?? 0))} className="h-1.5" />
                  </div>
                ))
              ) : (
                <p className="text-center text-slate-400 text-xs py-2">Sin centros de costo</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
