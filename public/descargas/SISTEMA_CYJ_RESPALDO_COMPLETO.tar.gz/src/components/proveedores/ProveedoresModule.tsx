'use client'

import { useEffect, useState, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Plus, Pencil, Trash2, Search, Download, Upload, FileSpreadsheet, CheckCircle, XCircle, AlertCircle } from 'lucide-react'
import * as XLSX from 'xlsx'
import { toast } from 'sonner'

interface Proveedor {
  id: string
  razonSocial: string
  rut: string | null
  giro: string | null
  direccion: string | null
  comuna: string | null
  telCorp: string | null
  emailCorp: string | null
  web: string | null
  contacto: string | null
  cargo: string | null
  telDirecto: string | null
  emailContacto: string | null
  celular: string | null
  estado: string
  notas: string | null
}

interface ImportResult {
  success: boolean
  total: number
  created: number
  updated: number
  skipped: number
  errors: string[]
}

const estadoColors: Record<string, string> = {
  'Activo': 'bg-green-100 text-green-700',
  'Inactivo': 'bg-slate-100 text-slate-700',
  'En revisión': 'bg-yellow-100 text-yellow-700',
}

export function ProveedoresModule() {
  const [proveedores, setProveedores] = useState<Proveedor[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingProv, setEditingProv] = useState<Proveedor | null>(null)
  
  // Bulk upload states
  const [bulkDialogOpen, setBulkDialogOpen] = useState(false)
  const [previewData, setPreviewData] = useState<Record<string, unknown>[]>([])
  const [previewHeaders, setPreviewHeaders] = useState<string[]>([])
  const [allData, setAllData] = useState<Record<string, unknown>[]>([])
  const [importing, setImporting] = useState(false)
  const [importResult, setImportResult] = useState<ImportResult | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const [formData, setFormData] = useState({
    razonSocial: '',
    rut: '',
    giro: '',
    direccion: '',
    comuna: '',
    telCorp: '',
    emailCorp: '',
    web: '',
    contacto: '',
    cargo: '',
    telDirecto: '',
    emailContacto: '',
    celular: '',
    estado: 'Activo',
    notas: '',
  })

  const fetchProveedores = async (searchTerm = '') => {
    setLoading(true)
    try {
      const url = searchTerm ? `/api/proveedores?search=${encodeURIComponent(searchTerm)}` : '/api/proveedores'
      const res = await fetch(url)
      const data = await res.json()
      setProveedores(data)
    } catch (error) {
      console.error('Error fetching proveedores:', error)
    }
    setLoading(false)
  }

  useEffect(() => {
    fetchProveedores()
  }, [])

  useEffect(() => {
    const timeout = setTimeout(() => fetchProveedores(search), 300)
    return () => clearTimeout(timeout)
  }, [search])

  const openDialog = (prov?: Proveedor) => {
    if (prov) {
      setEditingProv(prov)
      setFormData({
        razonSocial: prov.razonSocial,
        rut: prov.rut || '',
        giro: prov.giro || '',
        direccion: prov.direccion || '',
        comuna: prov.comuna || '',
        telCorp: prov.telCorp || '',
        emailCorp: prov.emailCorp || '',
        web: prov.web || '',
        contacto: prov.contacto || '',
        cargo: prov.cargo || '',
        telDirecto: prov.telDirecto || '',
        emailContacto: prov.emailContacto || '',
        celular: prov.celular || '',
        estado: prov.estado,
        notas: prov.notas || '',
      })
    } else {
      setEditingProv(null)
      setFormData({
        razonSocial: '',
        rut: '',
        giro: '',
        direccion: '',
        comuna: '',
        telCorp: '',
        emailCorp: '',
        web: '',
        contacto: '',
        cargo: '',
        telDirecto: '',
        emailContacto: '',
        celular: '',
        estado: 'Activo',
        notas: '',
      })
    }
    setDialogOpen(true)
  }

  const handleSave = async () => {
    if (!formData.razonSocial.trim()) return

    try {
      if (editingProv) {
        await fetch(`/api/proveedores/${editingProv.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
        toast.success('Proveedor actualizado')
      } else {
        await fetch('/api/proveedores', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
        toast.success('Proveedor creado')
      }
      setDialogOpen(false)
      fetchProveedores(search)
    } catch (error) {
      console.error('Error saving proveedor:', error)
      toast.error('Error al guardar proveedor')
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar este proveedor?')) return
    try {
      await fetch(`/api/proveedores/${id}`, { method: 'DELETE' })
      toast.success('Proveedor eliminado')
      fetchProveedores(search)
    } catch (error) {
      console.error('Error deleting proveedor:', error)
      toast.error('Error al eliminar proveedor')
    }
  }

  // Exportar a CSV
  const exportToCSV = () => {
    const headers = ['Razón Social', 'RUT', 'Giro', 'Dirección', 'Comuna', 'Tel. Corp.', 'Email Corp.', 'Web', 'Contacto', 'Cargo', 'Tel. Directo', 'Email Contacto', 'Celular', 'Estado', 'Notas']
    
    const rows = proveedores.map(p => [
      `"${p.razonSocial.replace(/"/g, '""')}"`,
      p.rut || '',
      `"${(p.giro || '').replace(/"/g, '""')}"`,
      `"${(p.direccion || '').replace(/"/g, '""')}"`,
      p.comuna || '',
      p.telCorp || '',
      p.emailCorp || '',
      p.web || '',
      `"${(p.contacto || '').replace(/"/g, '""')}"`,
      p.cargo || '',
      p.telDirecto || '',
      p.emailContacto || '',
      p.celular || '',
      p.estado,
      `"${(p.notas || '').replace(/"/g, '""')}"`
    ])
    
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `proveedores_${new Date().toISOString().split('T')[0]}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
    toast.success('CSV exportado correctamente')
  }

  // Download template
  const downloadTemplate = () => {
    const template = [
      {
        'Razón Social': 'Empresa Ejemplo S.A.',
        'RUT': '76.123.456-7',
        'Giro': 'Servicios de Mantenimiento',
        'Dirección': 'Av. Principal 123',
        'Comuna': 'Santiago',
        'Tel. Corp.': '+56 2 2345 6789',
        'Email Corp.': 'contacto@empresa.cl',
        'Web': 'www.empresa.cl',
        'Contacto': 'Juan Pérez',
        'Cargo': 'Gerente Comercial',
        'Tel. Directo': '+56 2 2345 6790',
        'Email Contacto': 'jperez@empresa.cl',
        'Celular': '+56 9 1234 5678',
        'Estado': 'Activo',
        'Notas': 'Proveedor preferente para servicios eléctricos'
      }
    ]
    
    const ws = XLSX.utils.json_to_sheet(template)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'Proveedores')
    XLSX.writeFile(wb, 'plantilla_proveedores.xlsx')
    toast.success('Plantilla descargada')
  }

  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (evt) => {
      try {
        const data = evt.target?.result
        const workbook = XLSX.read(data, { type: 'binary' })
        const sheetName = workbook.SheetNames[0]
        const worksheet = workbook.Sheets[sheetName]
        const jsonData = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet)
        
        if (jsonData.length === 0) {
          toast.error('El archivo no contiene datos')
          return
        }

        // Get headers from first row
        const headers = Object.keys(jsonData[0])
        setPreviewHeaders(headers)
        setPreviewData(jsonData.slice(0, 10)) // Preview first 10 rows
        setAllData(jsonData) // Store all data
        setImportResult(null)
        setBulkDialogOpen(true)
      } catch (error) {
        console.error('Error reading file:', error)
        toast.error('Error al leer el archivo. Asegúrese de que es un archivo Excel válido.')
      }
    }
    reader.readAsBinaryString(file)
    
    // Reset input
    e.target.value = ''
  }

  // Process import
  const handleImport = async () => {
    if (allData.length === 0) return

    setImporting(true)
    try {
      const response = await fetch('/api/proveedores/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proveedores: allData })
      })

      const result = await response.json()
      setImportResult(result)

      if (result.success) {
        fetchProveedores(search)
        toast.success(`Importación completada: ${result.created} creados, ${result.updated} actualizados`)
      }
    } catch (error) {
      console.error('Error importing:', error)
      setImportResult({
        success: false,
        total: 0,
        created: 0,
        updated: 0,
        skipped: 0,
        errors: ['Error al procesar el archivo']
      })
      toast.error('Error al importar proveedores')
    } finally {
      setImporting(false)
    }
  }

  const resetBulkUpload = () => {
    setPreviewData([])
    setPreviewHeaders([])
    setAllData([])
    setImportResult(null)
    setBulkDialogOpen(false)
  }

  return (
    <div className="space-y-5">
      {/* Actions */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Buscar..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button variant="outline" size="sm" onClick={downloadTemplate}>
          <FileSpreadsheet className="w-4 h-4 mr-1" /> Plantilla
        </Button>
        <Button variant="outline" size="sm" onClick={exportToCSV}>
          <Download className="w-4 h-4 mr-1" /> Exportar
        </Button>
        <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
          <Upload className="w-4 h-4 mr-1" /> Cargar
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls,.csv"
          onChange={handleFileSelect}
          className="hidden"
        />
        <Button size="sm" onClick={() => openDialog()}>
          <Plus className="w-4 h-4 mr-1" /> Nuevo
        </Button>
      </div>

      {/* Mobile View: Cards */}
      <div className="md:hidden space-y-3">
        {loading ? (
          <Card><CardContent className="p-8 text-center text-slate-400">Cargando...</CardContent></Card>
        ) : proveedores.length === 0 ? (
          <Card><CardContent className="p-8 text-center text-slate-400">Sin proveedores</CardContent></Card>
        ) : (
          proveedores.map((prov) => (
            <Card key={prov.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{prov.razonSocial}</p>
                    <p className="text-xs text-slate-500">{prov.giro || 'Sin giro'}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className={estadoColors[prov.estado] || 'bg-slate-100'} variant="secondary">
                        {prov.estado}
                      </Badge>
                      {prov.rut && <span className="text-xs font-mono">{prov.rut}</span>}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openDialog(prov)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-red-600" onClick={() => handleDelete(prov.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Desktop View: Table */}
      <Card className="hidden md:block">
        <CardHeader className="py-3">
          <CardTitle className="text-sm">Proveedores ({proveedores.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-slate-50">
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Razón Social</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">RUT</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Giro</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Comuna</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Tel. Corp.</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Contacto</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Estado</th>
                  <th className="text-center p-3 text-[10px] font-bold text-slate-500 uppercase">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={8} className="p-8 text-center text-slate-400">Cargando...</td></tr>
                ) : proveedores.length === 0 ? (
                  <tr><td colSpan={8} className="p-8 text-center text-slate-400">Sin proveedores</td></tr>
                ) : (
                  proveedores.map((prov) => (
                    <tr key={prov.id} className="border-b last:border-0 hover:bg-slate-50">
                      <td className="p-3 font-semibold">{prov.razonSocial}</td>
                      <td className="p-3 font-mono text-xs">{prov.rut || '–'}</td>
                      <td className="p-3 text-xs text-slate-600">{prov.giro || '–'}</td>
                      <td className="p-3 text-xs">{prov.comuna || '–'}</td>
                      <td className="p-3 text-xs">{prov.telCorp || '–'}</td>
                      <td className="p-3 text-xs">{prov.contacto || '–'}</td>
                      <td className="p-3">
                        <Badge className={estadoColors[prov.estado] || 'bg-slate-100'}>{prov.estado}</Badge>
                      </td>
                      <td className="p-3">
                        <div className="flex justify-center gap-1">
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openDialog(prov)}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7 text-red-600 hover:text-red-700" onClick={() => handleDelete(prov.id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Dialog para crear/editar */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingProv ? 'Editar' : 'Nuevo'} Proveedor</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Razón Social *</Label>
                <Input value={formData.razonSocial} onChange={(e) => setFormData({...formData, razonSocial: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>RUT</Label>
                <Input placeholder="76.123.456-7" value={formData.rut} onChange={(e) => setFormData({...formData, rut: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Giro</Label>
                <Input value={formData.giro} onChange={(e) => setFormData({...formData, giro: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Dirección</Label>
                <Input value={formData.direccion} onChange={(e) => setFormData({...formData, direccion: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Comuna</Label>
                <Input value={formData.comuna} onChange={(e) => setFormData({...formData, comuna: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Tel. Corporativo</Label>
                <Input value={formData.telCorp} onChange={(e) => setFormData({...formData, telCorp: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Email Corporativo</Label>
                <Input type="email" value={formData.emailCorp} onChange={(e) => setFormData({...formData, emailCorp: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Página Web</Label>
                <Input value={formData.web} onChange={(e) => setFormData({...formData, web: e.target.value})} />
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="text-xs font-semibold text-slate-500 mb-3">PERSONA DE CONTACTO</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Contacto</Label>
                  <Input value={formData.contacto} onChange={(e) => setFormData({...formData, contacto: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Cargo</Label>
                  <Input value={formData.cargo} onChange={(e) => setFormData({...formData, cargo: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Tel. Directo</Label>
                  <Input value={formData.telDirecto} onChange={(e) => setFormData({...formData, telDirecto: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Email Contacto</Label>
                  <Input type="email" value={formData.emailContacto} onChange={(e) => setFormData({...formData, emailContacto: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Celular</Label>
                  <Input value={formData.celular} onChange={(e) => setFormData({...formData, celular: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Estado</Label>
                  <select 
                    className="flex h-10 w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm"
                    value={formData.estado} 
                    onChange={(e) => setFormData({...formData, estado: e.target.value})}
                  >
                    {['Activo', 'Inactivo', 'En revisión'].map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Notas</Label>
              <Textarea value={formData.notas} onChange={(e) => setFormData({...formData, notas: e.target.value})} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleSave}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog para carga masiva */}
      <Dialog open={bulkDialogOpen} onOpenChange={(open) => { if (!open) resetBulkUpload() }}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Carga Masiva de Proveedores</DialogTitle>
          </DialogHeader>
          
          {!importResult ? (
            <>
              {/* Preview */}
              <div className="py-4">
                <p className="text-sm text-muted-foreground mb-4">
                  Se detectaron <strong>{allData.length}</strong> registros. 
                  Mostrando primeros 10.
                </p>
                
                <ScrollArea className="h-[300px] border rounded-lg">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 sticky top-0">
                      <tr>
                        {previewHeaders.map((h) => (
                          <th key={h} className="p-2 text-left font-semibold border-b whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {previewData.map((row, i) => (
                        <tr key={i} className="border-b hover:bg-slate-50">
                          {previewHeaders.map((h) => (
                            <td key={h} className="p-2 whitespace-nowrap">
                              {row[h] !== undefined ? String(row[h]).substring(0, 40) : '-'}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </ScrollArea>
                
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-700">
                    <strong>Nota:</strong> Los proveedores se actualizarán si coinciden por RUT o Razón Social.
                    Solo se actualizarán los campos no vacíos del archivo.
                  </p>
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={resetBulkUpload}>Cancelar</Button>
                <Button onClick={handleImport} disabled={importing}>
                  {importing ? (
                    <span className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Importando...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Importar {allData.length} registros
                    </span>
                  )}
                </Button>
              </DialogFooter>
            </>
          ) : (
            /* Results */
            <div className="py-4 space-y-4">
              <div className={`p-4 rounded-lg ${importResult.success ? 'bg-green-50' : 'bg-red-50'}`}>
                <div className="flex items-center gap-2">
                  {importResult.success ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-600" />
                  )}
                  <span className={`font-semibold ${importResult.success ? 'text-green-700' : 'text-red-700'}`}>
                    {importResult.success ? 'Importación completada' : 'Error en importación'}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 bg-slate-50 rounded-lg text-center">
                  <p className="text-2xl font-bold">{importResult.total}</p>
                  <p className="text-xs text-muted-foreground">Total</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg text-center">
                  <p className="text-2xl font-bold text-green-600">{importResult.created}</p>
                  <p className="text-xs text-muted-foreground">Creados</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg text-center">
                  <p className="text-2xl font-bold text-blue-600">{importResult.updated}</p>
                  <p className="text-xs text-muted-foreground">Actualizados</p>
                </div>
                <div className="p-4 bg-yellow-50 rounded-lg text-center">
                  <p className="text-2xl font-bold text-yellow-600">{importResult.skipped}</p>
                  <p className="text-xs text-muted-foreground">Omitidos</p>
                </div>
              </div>
              
              {importResult.errors.length > 0 && (
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-4 h-4 text-yellow-600" />
                    <span className="font-medium text-yellow-700">Advertencias:</span>
                  </div>
                  <ScrollArea className="h-[100px]">
                    <ul className="text-xs text-yellow-600 space-y-1">
                      {importResult.errors.map((err, i) => (
                        <li key={i}>• {err}</li>
                      ))}
                    </ul>
                  </ScrollArea>
                </div>
              )}
            </div>
          )}
          
          {importResult && (
            <DialogFooter>
              <Button onClick={resetBulkUpload}>Cerrar</Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
