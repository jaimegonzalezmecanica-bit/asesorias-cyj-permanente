'use client'

import { 
  LayoutDashboard, 
  Users, 
  Wrench, 
  DraftingCompass, 
  Search, 
  User, 
  Package, 
  Building2, 
  Receipt, 
  PiggyBank, 
  FileText,
  LogOut,
  ChevronUp,
  Shield,
  UserCog,
  Calendar,
  DollarSign,
  AlertTriangle,
  Bell,
  Calculator,
  CheckCircle,
  Scale,
  ClipboardCheck,
  QrCode,
  Eye,
  Menu,
  X,
  Home
} from 'lucide-react'
import { useAppStore, type Module } from '@/lib/store'
import { cn } from '@/lib/utils'
import { useSession } from '@/hooks/use-session'
import { useRouter } from 'next/navigation'
import { useIsMobile } from '@/hooks/use-mobile'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'

// Definir permisos necesarios para cada módulo
// Si un módulo requiere permiso, el usuario debe tener ese permiso para verlo
// Los admin ven todo automáticamente
const modulePermissions: Partial<Record<Module, string>> = {
  dashboard: undefined, // Dashboard es visible para todos
  residentes: 'residentes.ver',
  ot: 'ots.ver',
  proyectos: 'proyectos.ver',
  inspecciones: 'inspecciones.ver',
  personal: 'personal.ver',
  activos: 'activos.ver',
  proveedores: 'proveedores.ver',
  gastos: 'gastos.ver',
  centrocostos: 'centros-costo.ver',
  materiales: 'catalogos.ver',
  tareas: 'catalogos.ver',
  herramientas: 'catalogos.ver',
  reportes: 'reportes.ver',
  inventario: 'inventario.ver',
  catalogos: 'catalogos.ver',
  reservas: 'reservas.ver',
  gastoscomunes: 'gastos.ver',
  morosidad: 'gastos.ver',
  notificaciones: 'usuarios.ver',
  contabilidad: 'gastos.ver',
  cumplimiento: 'cumplimiento.ver',
  auditoria: 'auditoria.ver',
  aprobacionesot: 'ots.aprobar',
  asistencia: 'personal.ver',
  rondas: 'rondas.ver',
  usuarios: 'usuarios.ver',
}

const menuItems: { section: string; items: { id: Module; label: string; icon: React.ReactNode }[] }[] = [
  {
    section: 'Principal',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    ]
  },
  {
    section: 'Gestión',
    items: [
      { id: 'residentes', label: 'Residentes', icon: <Users className="w-4 h-4" /> },
      { id: 'reservas', label: 'Reservas', icon: <Calendar className="w-4 h-4" /> },
      { id: 'ot', label: 'Órdenes de Trabajo', icon: <Wrench className="w-4 h-4" /> },
      { id: 'aprobacionesot', label: 'Aprobaciones OT', icon: <CheckCircle className="w-4 h-4" /> },
      { id: 'proyectos', label: 'Proyectos', icon: <DraftingCompass className="w-4 h-4" /> },
      { id: 'inspecciones', label: 'Inspecciones', icon: <Search className="w-4 h-4" /> },
      { id: 'personal', label: 'Personal', icon: <User className="w-4 h-4" /> },
      { id: 'asistencia', label: 'Control Asistencia', icon: <Calendar className="w-4 h-4" /> },
      { id: 'activos', label: 'Activos', icon: <Package className="w-4 h-4" /> },
      { id: 'inventario', label: 'Inventario', icon: <Package className="w-4 h-4" /> },
      { id: 'rondas', label: 'Rondas', icon: <QrCode className="w-4 h-4" /> },
    ]
  },
  {
    section: 'Finanzas',
    items: [
      { id: 'gastoscomunes', label: 'Gastos Comunes', icon: <DollarSign className="w-4 h-4" /> },
      { id: 'morosidad', label: 'Morosidad', icon: <AlertTriangle className="w-4 h-4" /> },
      { id: 'proveedores', label: 'Proveedores', icon: <Building2 className="w-4 h-4" /> },
      { id: 'gastos', label: 'Gastos / Rendición', icon: <Receipt className="w-4 h-4" /> },
      { id: 'centrocostos', label: 'Centro de Costos', icon: <PiggyBank className="w-4 h-4" /> },
      { id: 'contabilidad', label: 'Contabilidad', icon: <Calculator className="w-4 h-4" /> },
    ]
  },
  {
    section: 'Catálogos',
    items: [
      { id: 'materiales', label: 'Materiales', icon: <Package className="w-4 h-4" /> },
      { id: 'tareas', label: 'Tareas', icon: <Wrench className="w-4 h-4" /> },
      { id: 'herramientas', label: 'Herramientas', icon: <Wrench className="w-4 h-4" /> },
    ]
  },
  {
    section: 'Sistema',
    items: [
      { id: 'cumplimiento', label: 'Cumplimiento Legal', icon: <Scale className="w-4 h-4" /> },
      { id: 'auditoria', label: 'Auditoría', icon: <ClipboardCheck className="w-4 h-4" /> },
      { id: 'notificaciones', label: 'Notificaciones', icon: <Bell className="w-4 h-4" /> },
      { id: 'reportes', label: 'Reportes', icon: <FileText className="w-4 h-4" /> },
      { id: 'usuarios', label: 'Usuarios', icon: <Users className="w-4 h-4" /> },
    ]
  },
]

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { currentModule, setCurrentModule } = useAppStore()
  const { user, logout, hasPermission, isAdmin } = useSession()
  const router = useRouter()

  // Filtrar menú según permisos
  // Reglas:
  // 1. Dashboard es visible para todos
  // 2. Admin ve todo
  // 3. Otros usuarios solo ven módulos para los que tienen permiso explícito
  const filteredMenuItems = menuItems.map(section => ({
    ...section,
    items: section.items.filter(item => {
      // Dashboard siempre visible
      if (item.id === 'dashboard') return true
      
      // Admin ve todo
      if (isAdmin()) return true
      
      const permission = modulePermissions[item.id]
      
      // Si el módulo tiene permiso definido, verificar
      if (permission) {
        return hasPermission(permission)
      }
      
      // Si no tiene permiso definido y no es admin, NO mostrar
      return false
    })
  })).filter(section => section.items.length > 0)

  const handleLogout = async () => {
    await logout()
    router.push('/login')
  }

  const handleNavigate = (module: Module) => {
    setCurrentModule(module)
    onNavigate?.()
  }

  const getInitials = () => {
    if (!user) return '?'
    const initials = user.nombre.charAt(0) + (user.apellido?.charAt(0) || '')
    return initials.toUpperCase()
  }

  const getRoleLabel = () => {
    switch (user?.rol) {
      case 'admin':
        return 'Administrador'
      case 'supervisor':
        return 'Supervisor'
      case 'auditor':
        return 'Auditor'
      case 'personal':
        return 'Personal'
      default:
        return 'Usuario'
    }
  }

  const getRoleIcon = () => {
    switch (user?.rol) {
      case 'admin':
        return <Shield className="w-3 h-3" />
      case 'supervisor':
        return <UserCog className="w-3 h-3" />
      case 'auditor':
        return <Eye className="w-3 h-3" />
      case 'personal':
        return <Wrench className="w-3 h-3" />
      default:
        return <User className="w-3 h-3" />
    }
  }

  return (
    <div className="flex flex-col h-full bg-[#0f2040]">
      {/* Logo */}
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center gap-2">
          <img 
            src="/logo.jpg" 
            alt="Asesorías Integrales CyJ" 
            className="w-10 h-10 rounded-lg object-cover"
          />
          <div>
            <div className="text-white text-xs font-bold leading-tight">Asesorías Integrales CyJ</div>
            <div className="text-blue-300 text-[9px] font-medium">Administración de Condominios</div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto sidebar-scroll">
        <nav className="p-2">
          {filteredMenuItems.map((section) => (
            <div key={section.section} className="mb-2">
              <div className="px-3 py-2 text-[10px] font-bold text-white/30 uppercase tracking-wider">
                {section.section}
              </div>
              {section.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavigate(item.id)}
                  className={cn(
                    'w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
                    currentModule === item.id
                      ? 'bg-amber-500/20 text-amber-500'
                      : 'text-white/60 hover:bg-white/10 hover:text-white'
                  )}
                >
                  {item.icon}
                  <span className="truncate">{item.label}</span>
                </button>
              ))}
            </div>
          ))}
        </nav>
      </div>

      {/* User Menu */}
      {user && (
        <div className="p-2 border-t border-white/10">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className="w-full justify-start gap-2 px-2 py-2 h-auto text-white/70 hover:text-white hover:bg-white/10"
              >
                <Avatar className="h-8 w-8 bg-amber-500/20 text-amber-500">
                  <AvatarFallback className="bg-amber-500/20 text-amber-500 text-xs font-bold">
                    {getInitials()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 text-left">
                  <div className="text-xs font-medium truncate">
                    {user.nombre} {user.apellido}
                  </div>
                  <div className="text-[10px] text-white/50 flex items-center gap-1">
                    {getRoleIcon()}
                    {getRoleLabel()}
                  </div>
                </div>
                <ChevronUp className="h-4 w-4 text-white/50 ml-auto" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
              align="end" 
              className="w-48 bg-[#1a3155] border-white/10 text-white"
            >
              <div className="px-2 py-1.5 text-xs text-white/50">
                {user.email}
              </div>
              <DropdownMenuSeparator className="bg-white/10" />
              
              {isAdmin() && (
                <>
                  <DropdownMenuItem 
                    className="text-white/70 focus:text-white focus:bg-white/10 cursor-pointer"
                    onClick={() => handleNavigate('usuarios')}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    Gestionar Usuarios
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-white/10" />
                </>
              )}
              
              <DropdownMenuItem 
                className="text-red-400 focus:text-red-300 focus:bg-red-500/10 cursor-pointer"
                onClick={handleLogout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Cerrar Sesión
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}

      {/* Footer */}
      <div className="p-3 border-t border-white/10">
        <div className="text-white/25 text-[9px] text-center leading-relaxed">
          Asesorías Integrales CyJ<br/>
          Administración de Condominios<br/>
          +56 964 650 643 | +56 974 408 794
        </div>
      </div>
    </div>
  )
}

export function Sidebar() {
  const { sidebarOpen, setSidebarOpen } = useAppStore()
  const { loading, authenticated } = useSession()
  const isMobile = useIsMobile()

  if (loading && !authenticated) {
    return null
  }

  // Mobile: Sheet/Drawer
  if (isMobile) {
    return (
      <>
        {/* Mobile Header */}
        <header className="fixed top-0 left-0 right-0 h-14 bg-[#0f2040] border-b border-white/10 flex items-center justify-between px-4 z-40">
          <div className="flex items-center gap-2">
            <img 
              src="/logo.jpg" 
              alt="Asesorías Integrales CyJ" 
              className="w-8 h-8 rounded-lg object-cover"
            />
            <div>
              <div className="text-white text-xs font-bold leading-tight">Asesorías CyJ</div>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(true)}
            className="text-white hover:bg-white/10"
          >
            <Menu className="w-5 h-5" />
          </Button>
        </header>

        {/* Mobile Drawer */}
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetContent side="left" className="p-0 w-72 bg-[#0f2040] border-r-0">
            <SheetHeader className="sr-only">
              <SheetTitle>Menú de navegación</SheetTitle>
            </SheetHeader>
            <SidebarContent onNavigate={() => setSidebarOpen(false)} />
          </SheetContent>
        </Sheet>
      </>
    )
  }

  // Desktop: Fixed Sidebar
  return (
    <aside className="w-56 bg-[#0f2040] flex flex-col h-full shrink-0">
      <SidebarContent />
    </aside>
  )
}
