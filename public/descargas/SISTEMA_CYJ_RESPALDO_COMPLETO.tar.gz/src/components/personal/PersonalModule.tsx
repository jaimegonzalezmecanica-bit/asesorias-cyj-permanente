'use client'

import { useEffect, useState, useRef, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Plus, Pencil, Trash2, Search, DollarSign, Upload } from 'lucide-react'
import { useSession } from '@/hooks/use-session'
import { useExport, ColumnConfig, FilterField } from '@/hooks/use-export'

interface Personal {
  id: string
  nombre: string
  rut: string | null
  cargo: string | null
  contrato: string
  afp: string
  salud: string
  mutual: string
  ccaf: string | null
  fechaIngreso: string | null
  sueldoBase: number
  movilizacion: number
  colacion: number
  viatico: number
  asigFamiliar: number
  estado: string
  email: string | null
  telefono: string | null
  notas: string | null
}

const formatCLP = (n: number) => 
  '$' + new Intl.NumberFormat('es-CL').format(Math.round(n || 0))

const contratoColors: Record<string, string> = {
  'Indefinido': 'bg-blue-100 text-blue-700',
  'Plazo Fijo': 'bg-yellow-100 text-yellow-700',
  'Por Obra': 'bg-purple-100 text-purple-700',
  'Part-Time': 'bg-cyan-100 text-cyan-700',
}

const estadoColors: Record<string, string> = {
  'Activo': 'bg-green-100 text-green-700',
  'Vacaciones': 'bg-cyan-100 text-cyan-700',
  'Licencia': 'bg-purple-100 text-purple-700',
  'Inactivo': 'bg-slate-100 text-slate-700',
}

export function PersonalModule() {
  const [personal, setPersonal] = useState<Personal[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [importDialogOpen, setImportDialogOpen] = useState(false)
  const [importStatus, setImportStatus] = useState<{ loading: boolean; message: string }>({ loading: false, message: '' })
  const [editingPer, setEditingPer] = useState<Personal | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const { hasPermission } = useSession()
  const canEdit = hasPermission('personal.editar')
  
  const [formData, setFormData] = useState({
    nombre: '',
    rut: '',
    cargo: '',
    contrato: 'Indefinido',
    afp: 'ProVida',
    salud: 'Fonasa',
    mutual: 'IST',
    ccaf: '',
    fechaIngreso: new Date().toISOString().split('T')[0],
    sueldoBase: 0,
    movilizacion: 0,
    colacion: 0,
    viatico: 0,
    asigFamiliar: 0,
    estado: 'Activo',
    email: '',
    telefono: '',
    notas: '',
  })

  // Export configuration
  const exportColumns: ColumnConfig[] = useMemo(() => [
    { key: 'nombre', label: 'Nombre', defaultVisible: true },
    { key: 'rut', label: 'RUT', defaultVisible: true },
    { key: 'cargo', label: 'Cargo', defaultVisible: true },
    { key: 'contrato', label: 'Contrato', defaultVisible: true },
    { key: 'afp', label: 'AFP', defaultVisible: true },
    { key: 'salud', label: 'Salud', defaultVisible: true },
    { key: 'sueldoBase', label: 'Sueldo Base', defaultVisible: true },
    { key: 'movilizacion', label: 'Movilización', defaultVisible: true },
    { key: 'colacion', label: 'Colación', defaultVisible: true },
    { key: 'viatico', label: 'Viático', defaultVisible: false },
    { key: 'asigFamiliar', label: 'Asig. Familiar', defaultVisible: false },
    { key: 'estado', label: 'Estado', defaultVisible: true },
    { key: 'telefono', label: 'Teléfono', defaultVisible: true },
    { key: 'email', label: 'Email', defaultVisible: true },
    { key: 'fechaIngreso', label: 'Fecha Ingreso', defaultVisible: true },
  ], [])

  const exportFilters: FilterField[] = useMemo(() => [
    { key: 'estado', label: 'Estado', type: 'select', options: ['Activo', 'Vacaciones', 'Licencia', 'Inactivo'] },
    { key: 'contrato', label: 'Contrato', type: 'select', options: ['Indefinido', 'Plazo Fijo', 'Por Obra', 'Part-Time'] },
  ], [])

  const { ExportButton } = useExport({
    moduleName: 'personal',
    moduleLabel: 'Personal',
    columns: exportColumns,
    filters: exportFilters,
    getData: () => personal
  })

  const fetchPersonal = async (searchTerm = '') => {
    setLoading(true)
    try {
      const url = searchTerm ? `/api/personal?search=${encodeURIComponent(searchTerm)}` : '/api/personal'
      const res = await fetch(url)
      const data = await res.json()
      setPersonal(data)
    } catch (error) {
      console.error('Error fetching personal:', error)
    }
    setLoading(false)
  }

  useEffect(() => {
    void (async () => {
      await fetchPersonal()
    })()
  }, [])

  useEffect(() => {
    const timeout = setTimeout(() => fetchPersonal(search), 300)
    return () => clearTimeout(timeout)
  }, [search])

  const openDialog = (per?: Personal) => {
    if (per) {
      setEditingPer(per)
      setFormData({
        nombre: per.nombre,
        rut: per.rut || '',
        cargo: per.cargo || '',
        contrato: per.contrato,
        afp: per.afp,
        salud: per.salud,
        mutual: per.mutual,
        ccaf: per.ccaf || '',
        fechaIngreso: per.fechaIngreso || new Date().toISOString().split('T')[0],
        sueldoBase: per.sueldoBase,
        movilizacion: per.movilizacion,
        colacion: per.colacion,
        viatico: per.viatico,
        asigFamiliar: per.asigFamiliar,
        estado: per.estado,
        email: per.email || '',
        telefono: per.telefono || '',
        notas: per.notas || '',
      })
    } else {
      setEditingPer(null)
      setFormData({
        nombre: '',
        rut: '',
        cargo: '',
        contrato: 'Indefinido',
        afp: 'ProVida',
        salud: 'Fonasa',
        mutual: 'IST',
        ccaf: '',
        fechaIngreso: new Date().toISOString().split('T')[0],
        sueldoBase: 0,
        movilizacion: 0,
        colacion: 0,
        viatico: 0,
        asigFamiliar: 0,
        estado: 'Activo',
        email: '',
        telefono: '',
        notas: '',
      })
    }
    setDialogOpen(true)
  }

  const handleSave = async () => {
    if (!formData.nombre.trim()) return

    try {
      if (editingPer) {
        await fetch(`/api/personal/${editingPer.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
      } else {
        await fetch('/api/personal', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
      }
      setDialogOpen(false)
      fetchPersonal(search)
    } catch (error) {
      console.error('Error saving personal:', error)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar este empleado?')) return
    try {
      await fetch(`/api/personal/${id}`, { method: 'DELETE' })
      fetchPersonal(search)
    } catch (error) {
      console.error('Error deleting personal:', error)
    }
  }

  // Importar desde Excel
  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setImportStatus({ loading: true, message: 'Procesando archivo...' })

    try {
      // Leer archivo Excel usando SheetJS (dinámico)
      const XLSX = await import('xlsx')
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data)
      const sheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[sheetName]
      const jsonData = XLSX.utils.sheet_to_json(worksheet)

      // Enviar al API
      const response = await fetch('/api/import/personal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ personal: jsonData }),
      })

      const result = await response.json()

      if (result.success) {
        setImportStatus({ 
          loading: false, 
          message: result.mensaje 
        })
        fetchPersonal()
      } else {
        setImportStatus({ 
          loading: false, 
          message: `Error: ${result.error}` 
        })
      }
    } catch (error) {
      console.error('Error importing:', error)
      setImportStatus({ 
        loading: false, 
        message: 'Error al procesar el archivo' 
      })
    }

    // Limpiar input
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  return (
    <div className="space-y-5">
      {/* Actions */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Buscar..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <ExportButton />
        <Button variant="outline" onClick={() => setImportDialogOpen(true)}>
          <Upload className="w-4 h-4 mr-1" /> Importar Excel
        </Button>
        <Button onClick={() => openDialog()}>
          <Plus className="w-4 h-4 mr-1" /> Nuevo
        </Button>
      </div>

      {/* Table */}
      <Card>
        <CardHeader className="py-3">
          <CardTitle className="text-sm">Personal ({personal.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-slate-50">
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Nombre</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">RUT</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Cargo</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Contrato</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">AFP</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Sueldo Base</th>
                  <th className="text-left p-3 text-[10px] font-bold text-slate-500 uppercase">Estado</th>
                  <th className="text-center p-3 text-[10px] font-bold text-slate-500 uppercase">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={8} className="p-8 text-center text-slate-400">Cargando...</td></tr>
                ) : personal.length === 0 ? (
                  <tr><td colSpan={8} className="p-8 text-center text-slate-400">Sin personal</td></tr>
                ) : (
                  personal.map((per) => (
                    <tr key={per.id} className="border-b last:border-0 hover:bg-slate-50">
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-7 w-7">
                            <AvatarFallback className="bg-[#0f2040] text-white text-xs font-bold">
                              {per.nombre.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-semibold">{per.nombre}</span>
                        </div>
                      </td>
                      <td className="p-3 font-mono text-xs">{per.rut || '–'}</td>
                      <td className="p-3">{per.cargo || '–'}</td>
                      <td className="p-3">
                        <Badge className={contratoColors[per.contrato] || 'bg-slate-100'}>{per.contrato}</Badge>
                      </td>
                      <td className="p-3 text-xs">{per.afp}</td>
                      <td className="p-3 font-mono text-xs">{formatCLP(per.sueldoBase)}</td>
                      <td className="p-3">
                        <Badge className={estadoColors[per.estado] || 'bg-slate-100'}>{per.estado}</Badge>
                      </td>
                      <td className="p-3">
                        <div className="flex justify-center gap-1">
                          <Button 
                            size="icon" 
                            variant="ghost" 
                            className="h-7 w-7 text-amber-600 hover:text-amber-700" 
                            title="Descargar Liquidación"
                            onClick={() => {
                              window.open(`/api/pdf/liquidacion/${per.id}`, '_blank')
                            }}
                          >
                            <DollarSign className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openDialog(per)}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7 text-red-600 hover:text-red-700" onClick={() => handleDelete(per.id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Import Dialog */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Importar Personal desde Excel</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="bg-slate-50 p-4 rounded-lg text-sm">
              <p className="font-semibold mb-2">Formato esperado del archivo Excel:</p>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>• <strong>Nombre:</strong> Nombre completo</li>
                <li>• <strong>RUT:</strong> RUT del empleado</li>
                <li>• <strong>Cargo:</strong> Cargo del empleado</li>
                <li>• <strong>Contrato:</strong> Indefinido, Plazo Fijo, etc.</li>
                <li>• <strong>AFP:</strong> AFP del empleado</li>
                <li>• <strong>Salud:</strong> Fonasa, Isapre, etc.</li>
                <li>• <strong>Sueldo:</strong> Sueldo base</li>
                <li>• <strong>Estado:</strong> Activo, Vacaciones, etc.</li>
              </ul>
            </div>
            
            <input
              type="file"
              accept=".xlsx,.xls"
              ref={fileInputRef}
              onChange={handleImport}
              className="hidden"
            />
            
            <Button 
              onClick={() => fileInputRef.current?.click()}
              disabled={importStatus.loading}
              className="w-full"
            >
              {importStatus.loading ? (
                <>Procesando...</>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Seleccionar archivo Excel
                </>
              )}
            </Button>
            
            {importStatus.message && (
              <div className={`p-3 rounded-lg text-sm ${
                importStatus.message.includes('Error') 
                  ? 'bg-red-50 text-red-700' 
                  : 'bg-green-50 text-green-700'
              }`}>
                {importStatus.message}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setImportDialogOpen(false)
              setImportStatus({ loading: false, message: '' })
            }}>
              Cerrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPer ? 'Editar' : 'Nuevo'} Empleado</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nombre Completo</Label>
                <Input value={formData.nombre} onChange={(e) => setFormData({...formData, nombre: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>RUT</Label>
                <Input value={formData.rut} onChange={(e) => setFormData({...formData, rut: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Cargo</Label>
                <Input value={formData.cargo} onChange={(e) => setFormData({...formData, cargo: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Contrato</Label>
                <Select value={formData.contrato} onValueChange={(v) => setFormData({...formData, contrato: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['Indefinido', 'Plazo Fijo', 'Por Obra', 'Part-Time'].map(t => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Fecha Ingreso</Label>
                <Input type="date" value={formData.fechaIngreso} onChange={(e) => setFormData({...formData, fechaIngreso: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Estado</Label>
                <Select value={formData.estado} onValueChange={(v) => setFormData({...formData, estado: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['Activo', 'Vacaciones', 'Licencia', 'Inactivo'].map(s => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="text-xs font-semibold text-slate-500 mb-3">REMUNERACIÓN</div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Sueldo Base ($)</Label>
                  <Input type="number" value={formData.sueldoBase} onChange={(e) => setFormData({...formData, sueldoBase: parseFloat(e.target.value) || 0})} />
                </div>
                <div className="space-y-2">
                  <Label>Movilización ($)</Label>
                  <Input type="number" value={formData.movilizacion} onChange={(e) => setFormData({...formData, movilizacion: parseFloat(e.target.value) || 0})} />
                </div>
                <div className="space-y-2">
                  <Label>Colación ($)</Label>
                  <Input type="number" value={formData.colacion} onChange={(e) => setFormData({...formData, colacion: parseFloat(e.target.value) || 0})} />
                </div>
                <div className="space-y-2">
                  <Label>Viático ($)</Label>
                  <Input type="number" value={formData.viatico} onChange={(e) => setFormData({...formData, viatico: parseFloat(e.target.value) || 0})} />
                </div>
                <div className="space-y-2">
                  <Label>Asignación Familiar ($)</Label>
                  <Input type="number" value={formData.asigFamiliar} onChange={(e) => setFormData({...formData, asigFamiliar: parseFloat(e.target.value) || 0})} />
                </div>
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="text-xs font-semibold text-slate-500 mb-3">PREVISIÓN</div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>AFP</Label>
                  <Select value={formData.afp} onValueChange={(v) => setFormData({...formData, afp: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['ProVida', 'Cuprum', 'Habitat', 'Capital', 'Planvital', 'Modelo', 'Uno'].map(a => (
                        <SelectItem key={a} value={a}>{a}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Salud</Label>
                  <Select value={formData.salud} onValueChange={(v) => setFormData({...formData, salud: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['Fonasa', 'Cruz del Norte', 'Banmédica', 'Colmena', 'Consalud', 'Vida Tres', 'MasVida'].map(s => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Mutual</Label>
                  <Select value={formData.mutual} onValueChange={(v) => setFormData({...formData, mutual: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['IST', 'ACHS', 'Mutual de Seguridad', 'CChC'].map(m => (
                        <SelectItem key={m} value={m}>{m}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>CCAF</Label>
                  <Input value={formData.ccaf} onChange={(e) => setFormData({...formData, ccaf: e.target.value})} />
                </div>
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="text-xs font-semibold text-slate-500 mb-3">CONTACTO</div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Teléfono</Label>
                  <Input value={formData.telefono} onChange={(e) => setFormData({...formData, telefono: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Notas</Label>
              <Textarea value={formData.notas} onChange={(e) => setFormData({...formData, notas: e.target.value})} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleSave}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
