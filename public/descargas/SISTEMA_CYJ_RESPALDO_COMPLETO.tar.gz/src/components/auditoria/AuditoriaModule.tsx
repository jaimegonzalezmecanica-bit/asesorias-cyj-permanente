'use client'

import { useState, useEffect, useCallback } from 'react'
import { useAppStore, type CondominioInfo } from '@/lib/store'
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from '@/components/ui/table'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  ClipboardCheck, Plus, Search, MoreHorizontal, Edit, Trash2, Eye,
  AlertTriangle, CheckCircle, Clock, XCircle, FileText,
  Building2, CheckSquare, FileSpreadsheet, Printer,
  Target, ArrowRight
} from 'lucide-react'
import { toast } from 'sonner'

interface AuditoriaItem {
  id: string
  codigo: string
  titulo: string
  tipo: string
  categoria: string
  estado: string
  fechaInicio: string | null
  fechaFin: string | null
  responsable: string | null
  alcance: string | null
  objetivo: string | null
  conclusiones: string | null
  puntuacionTotal: number
  itemsCriticos: number
  itemsMayores: number
  itemsMenores: number
  condominioId: string | null
  createdAt: string
  items?: AuditoriaCheckItem[]
  hallazgos?: AuditoriaHallazgoItem[]
  acciones?: AuditoriaAccionItem[]
}

interface AuditoriaCheckItem {
  id: string
  seccion: string
  pregunta: string
  descripcion: string | null
  obligatorio: boolean
  orden: number
  cumple: boolean | null
  evidencia: string | null
  observaciones: string | null
  calificacion: string | null
  criticidad: string | null
}

interface AuditoriaHallazgoItem {
  id: string
  codigo: string
  titulo: string
  descripcion: string
  tipo: string
  criticidad: string
  area: string | null
  estado: string
  fechaDeteccion: string
  fechaLimite: string | null
}

interface AuditoriaAccionItem {
  id: string
  codigo: string
  titulo: string
  descripcion: string
  tipo: string
  responsable: string | null
  fechaCompromiso: string | null
  estado: string
  hallazgoId: string | null
}

// Tipos de auditoría
const TIPOS_AUDITORIA = [
  { value: 'Interna', label: 'Interna', color: 'bg-blue-500' },
  { value: 'Externa', label: 'Externa', color: 'bg-purple-500' },
  { value: 'Legal', label: 'Legal', color: 'bg-red-500' },
  { value: 'Financiera', label: 'Financiera', color: 'bg-green-500' },
  { value: 'Operacional', label: 'Operacional', color: 'bg-amber-500' },
]

const CATEGORIAS_AUDITORIA = [
  'General', 'Financiera', 'Legal', 'Seguridad', 'Mantenimiento', 'Gestión'
]

const ESTADOS_AUDITORIA = [
  { value: 'Planificada', label: 'Planificada', color: 'bg-gray-500', icon: Clock },
  { value: 'En Ejecución', label: 'En Ejecución', color: 'bg-blue-500', icon: ClipboardCheck },
  { value: 'Completada', label: 'Completada', color: 'bg-green-500', icon: CheckCircle },
  { value: 'Cancelada', label: 'Cancelada', color: 'bg-red-500', icon: XCircle },
]

export function AuditoriaModule() {
  const { currentCondominio, setCurrentCondominio } = useAppStore()
  const [auditorias, setAuditorias] = useState<AuditoriaItem[]>([])
  const [condominios, setCondominios] = useState<CondominioInfo[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingCondominios, setLoadingCondominios] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterEstado, setFilterEstado] = useState<string>('all')
  const [filterTipo, setFilterTipo] = useState<string>('all')
  
  // Dialogs
  const [dialogOpen, setDialogOpen] = useState(false)
  const [detailDialogOpen, setDetailDialogOpen] = useState(false)
  const [hallazgoDialogOpen, setHallazgoDialogOpen] = useState(false)
  const [accionDialogOpen, setAccionDialogOpen] = useState(false)
  
  // Selected items
  const [selectedAuditoria, setSelectedAuditoria] = useState<AuditoriaItem | null>(null)
  
  // Form data
  const [formData, setFormData] = useState({
    titulo: '',
    tipo: 'Interna',
    categoria: 'General',
    fechaInicio: '',
    fechaFin: '',
    responsable: '',
    alcance: '',
    objetivo: '',
  })

  const [hallazgoForm, setHallazgoForm] = useState({
    codigo: '',
    titulo: '',
    descripcion: '',
    tipo: 'Observación',
    criticidad: 'Menor',
    area: '',
    fechaLimite: '',
  })

  const [accionForm, setAccionForm] = useState({
    codigo: '',
    titulo: '',
    descripcion: '',
    tipo: 'Correctiva',
    responsable: '',
    fechaCompromiso: '',
    hallazgoId: '',
  })

  // Cargar condominios
  const fetchCondominios = useCallback(async () => {
    try {
      const response = await fetch('/api/condominios')
      if (response.ok) {
        const data = await response.json()
        setCondominios(data)
        // Si no hay condominio seleccionado y hay condominios disponibles, seleccionar el primero
        if (!currentCondominio && data.length > 0) {
          setCurrentCondominio({
            id: data[0].id,
            nombre: data[0].nombre,
            direccion: data[0].direccion,
            comuna: data[0].comuna
          })
        }
      }
    } catch (error) {
      console.error('Error fetching condominios:', error)
    } finally {
      setLoadingCondominios(false)
    }
  }, [currentCondominio, setCurrentCondominio])

  const fetchAuditorias = useCallback(async () => {
    setLoading(true)
    try {
      // Si hay condominio seleccionado, filtrar por él
      const url = currentCondominio 
        ? `/api/auditoria?condominioId=${currentCondominio.id}`
        : '/api/auditoria'
      
      const response = await fetch(url)
      if (response.ok) {
        const data = await response.json()
        setAuditorias(data)
      }
    } catch (error) {
      console.error('Error fetching auditorias:', error)
      toast.error('Error al cargar las auditorías')
    } finally {
      setLoading(false)
    }
  }, [currentCondominio])

  useEffect(() => {
    fetchCondominios()
  }, [fetchCondominios])

  useEffect(() => {
    if (!loadingCondominios) {
      fetchAuditorias()
    }
  }, [fetchAuditorias, loadingCondominios])

  // Estadísticas
  const getStats = () => {
    const total = auditorias.length
    const planificadas = auditorias.filter(a => a.estado === 'Planificada').length
    const enEjecucion = auditorias.filter(a => a.estado === 'En Ejecución').length
    const completadas = auditorias.filter(a => a.estado === 'Completada').length
    const promedioPuntuacion = auditorias.length > 0 
      ? Math.round(auditorias.reduce((acc, a) => acc + a.puntuacionTotal, 0) / auditorias.length)
      : 0
    
    return { total, planificadas, enEjecucion, completadas, promedioPuntuacion }
  }

  const stats = getStats()

  // Filtrar auditorías
  const filteredAuditorias = auditorias.filter(a => {
    const matchSearch = a.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.codigo.toLowerCase().includes(searchTerm.toLowerCase())
    const matchEstado = filterEstado === 'all' || a.estado === filterEstado
    const matchTipo = filterTipo === 'all' || a.tipo === filterTipo
    return matchSearch && matchEstado && matchTipo
  })

  // Generar código de auditoría
  const generateCodigo = () => {
    const year = new Date().getFullYear()
    const count = auditorias.filter(a => a.codigo.includes(`AUD-${year}`)).length + 1
    return `AUD-${year}-${count.toString().padStart(3, '0')}`
  }

  // Crear auditoría
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const response = await fetch('/api/auditoria', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          codigo: generateCodigo(),
          condominioId: currentCondominio?.id || null,
        }),
      })
      
      if (response.ok) {
        toast.success('Auditoría creada correctamente')
        fetchAuditorias()
        setDialogOpen(false)
        resetForm()
      }
    } catch (error) {
      console.error('Error creating auditoria:', error)
      toast.error('Error al crear la auditoría')
    }
  }

  // Actualizar estado de auditoría
  const handleUpdateEstado = async (id: string, nuevoEstado: string) => {
    try {
      const response = await fetch(`/api/auditoria/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estado: nuevoEstado }),
      })
      
      if (response.ok) {
        toast.success('Estado actualizado')
        fetchAuditorias()
      }
    } catch (error) {
      console.error('Error updating estado:', error)
      toast.error('Error al actualizar estado')
    }
  }

  // Eliminar auditoría
  const handleDelete = async (id: string) => {
    if (!confirm('¿Está seguro de eliminar esta auditoría?')) return
    
    try {
      const response = await fetch(`/api/auditoria/${id}`, {
        method: 'DELETE',
      })
      if (response.ok) {
        toast.success('Auditoría eliminada')
        fetchAuditorias()
      }
    } catch (error) {
      console.error('Error deleting auditoria:', error)
      toast.error('Error al eliminar')
    }
  }

  // Ver detalle de auditoría
  const handleViewDetail = async (auditoria: AuditoriaItem) => {
    try {
      const response = await fetch(`/api/auditoria/${auditoria.id}`)
      if (response.ok) {
        const data = await response.json()
        setSelectedAuditoria(data)
        setDetailDialogOpen(true)
      }
    } catch (error) {
      console.error('Error fetching detail:', error)
      toast.error('Error al cargar detalle')
    }
  }

  // Actualizar item de checklist
  const handleUpdateItem = async (itemId: string, data: Partial<AuditoriaCheckItem>) => {
    if (!selectedAuditoria) return
    
    try {
      const response = await fetch(`/api/auditoria/${selectedAuditoria.id}/items/${itemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })
      
      if (response.ok) {
        // Recargar detalle
        handleViewDetail(selectedAuditoria)
        toast.success('Item actualizado')
      }
    } catch (error) {
      console.error('Error updating item:', error)
      toast.error('Error al actualizar item')
    }
  }

  // Crear hallazgo
  const handleCreateHallazgo = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedAuditoria) return
    
    try {
      const response = await fetch(`/api/auditoria/${selectedAuditoria.id}/hallazgos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...hallazgoForm,
          fechaDeteccion: new Date().toISOString().split('T')[0],
        }),
      })
      
      if (response.ok) {
        toast.success('Hallazgo registrado')
        handleViewDetail(selectedAuditoria)
        setHallazgoDialogOpen(false)
        setHallazgoForm({
          codigo: `H-${(selectedAuditoria.hallazgos?.length || 0) + 1}`,
          titulo: '',
          descripcion: '',
          tipo: 'Observación',
          criticidad: 'Menor',
          area: '',
          fechaLimite: '',
        })
      }
    } catch (error) {
      console.error('Error creating hallazgo:', error)
      toast.error('Error al registrar hallazgo')
    }
  }

  // Crear acción correctiva
  const handleCreateAccion = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedAuditoria) return
    
    try {
      const response = await fetch(`/api/auditoria/${selectedAuditoria.id}/acciones`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(accionForm),
      })
      
      if (response.ok) {
        toast.success('Acción creada')
        handleViewDetail(selectedAuditoria)
        setAccionDialogOpen(false)
        setAccionForm({
          codigo: `AC-${(selectedAuditoria.acciones?.length || 0) + 1}`,
          titulo: '',
          descripcion: '',
          tipo: 'Correctiva',
          responsable: '',
          fechaCompromiso: '',
          hallazgoId: '',
        })
      }
    } catch (error) {
      console.error('Error creating accion:', error)
      toast.error('Error al crear acción')
    }
  }

  const resetForm = () => {
    setFormData({
      titulo: '',
      tipo: 'Interna',
      categoria: 'General',
      fechaInicio: '',
      fechaFin: '',
      responsable: '',
      alcance: '',
      objetivo: '',
    })
  }

  const getEstadoBadge = (estado: string) => {
    const estadoInfo = ESTADOS_AUDITORIA.find(e => e.value === estado) || ESTADOS_AUDITORIA[0]
    const Icon = estadoInfo.icon
    return (
      <Badge className={`${estadoInfo.color} text-white flex items-center gap-1`}>
        <Icon className="w-3 h-3" />
        {estadoInfo.label}
      </Badge>
    )
  }

  const getTipoBadge = (tipo: string) => {
    const tipoInfo = TIPOS_AUDITORIA.find(t => t.value === tipo) || TIPOS_AUDITORIA[0]
    return (
      <Badge variant="outline" className="border-current">
        {tipoInfo.label}
      </Badge>
    )
  }

  const getCriticidadBadge = (criticidad: string) => {
    const colors: Record<string, string> = {
      'Crítica': 'bg-red-500 text-white',
      'Mayor': 'bg-orange-500 text-white',
      'Menor': 'bg-yellow-500 text-white',
    }
    return <Badge className={colors[criticidad] || ''}>{criticidad}</Badge>
  }

  // Función para exportar a CSV
  const exportCSV = () => {
    if (filteredAuditorias.length === 0) return
    
    const headers = ['Código', 'Título', 'Tipo', 'Categoría', 'Estado', 'Puntuación', 'Fecha Inicio', 'Fecha Fin', 'Responsable', 'Hallazgos', 'Acciones']
    const rows = filteredAuditorias.map(a => [
      a.codigo,
      a.titulo,
      a.tipo,
      a.categoria,
      a.estado,
      a.puntuacionTotal.toString(),
      a.fechaInicio || '',
      a.fechaFin || '',
      a.responsable || '',
      (a.hallazgos?.length || 0).toString(),
      (a.acciones?.length || 0).toString()
    ])
    
    const csv = [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n')
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `auditoria_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('CSV exportado correctamente')
  }

  // Función para exportar a PDF
  const exportPDF = () => {
    if (filteredAuditorias.length === 0) return
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Reporte de Auditorías</title>
        <style>
          * { box-sizing: border-box; margin: 0; padding: 0; }
          body { font-family: Arial, sans-serif; font-size: 10px; padding: 20px; }
          h1 { color: #0f2040; font-size: 14px; margin-bottom: 5px; }
          .header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; border-bottom: 3px solid #f0a500; padding-bottom: 12px; }
          .logo { width: 40px; height: 40px; background: #0f2040; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; font-size: 18px; }
          .stats { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin-bottom: 16px; }
          .stat { background: #f8fafc; padding: 8px; border-radius: 6px; text-align: center; }
          .stat-value { font-size: 16px; font-weight: bold; color: #0f2040; }
          .stat-label { font-size: 8px; color: #64748b; }
          table { width: 100%; border-collapse: collapse; }
          th { background: #0f2040; color: white; padding: 6px 8px; font-size: 9px; text-align: left; }
          td { padding: 5px 8px; border-bottom: 1px solid #e8ecf0; font-size: 9px; }
          tr:nth-child(even) td { background: #f8fafc; }
          .completada { background: #dcfce7 !important; }
          .ejecucion { background: #dbeafe !important; }
          .footer { margin-top: 12px; font-size: 8px; color: #94a3b8; text-align: center; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo">🏘️</div>
          <div>
            <h1>${currentCondominio?.nombre || 'Reporte de Auditorías'}</h1>
            <p style="font-size:11px;color:#64748b">Generado el ${new Date().toLocaleDateString('es-CL')}</p>
          </div>
        </div>
        
        <div class="stats">
          <div class="stat">
            <div class="stat-value">${stats.total}</div>
            <div class="stat-label">Total</div>
          </div>
          <div class="stat">
            <div class="stat-value">${stats.planificadas}</div>
            <div class="stat-label">Planificadas</div>
          </div>
          <div class="stat">
            <div class="stat-value">${stats.enEjecucion}</div>
            <div class="stat-label">En Ejecución</div>
          </div>
          <div class="stat">
            <div class="stat-value">${stats.completadas}</div>
            <div class="stat-label">Completadas</div>
          </div>
          <div class="stat">
            <div class="stat-value">${stats.promedioPuntuacion}%</div>
            <div class="stat-label">Puntuación Prom.</div>
          </div>
        </div>
        
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Código</th>
              <th>Título</th>
              <th>Tipo</th>
              <th>Estado</th>
              <th>Puntuación</th>
              <th>Fecha</th>
              <th>Hallazgos</th>
            </tr>
          </thead>
          <tbody>
            ${filteredAuditorias.map((a, i) => `
              <tr class="${a.estado === 'Completada' ? 'completada' : a.estado === 'En Ejecución' ? 'ejecucion' : ''}">
                <td>${i + 1}</td>
                <td>${a.codigo}</td>
                <td><b>${a.titulo}</b></td>
                <td>${a.tipo}</td>
                <td>${a.estado}</td>
                <td>${a.puntuacionTotal}%</td>
                <td>${a.fechaInicio ? new Date(a.fechaInicio).toLocaleDateString('es-CL') : '-'}</td>
                <td>${a.hallazgos?.length || 0}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div class="footer">
          Total: ${filteredAuditorias.length} registros | Generado: ${new Date().toLocaleString('es-CL')}
        </div>
      </body>
      </html>
    `
    
    const w = window.open('', '_blank', 'width=960,height=720')
    if (w) {
      w.document.open()
      w.document.write(html)
      w.document.close()
      w.onload = () => setTimeout(() => w.print(), 400)
    }
  }

  if (loadingCondominios) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground mt-2">Cargando...</p>
        </CardContent>
      </Card>
    )
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground mt-2">Cargando auditorías...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Selector de Condominio */}
      {condominios.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <Building2 className="w-5 h-5 text-muted-foreground" />
              <div className="flex-1">
                <Label className="text-sm text-muted-foreground">Condominio</Label>
                <Select 
                  value={currentCondominio?.id || 'all'} 
                  onValueChange={(v) => {
                    if (v === 'all') {
                      setCurrentCondominio(null)
                    } else {
                      const selected = condominios.find(c => c.id === v)
                      if (selected) {
                        setCurrentCondominio({
                          id: selected.id,
                          nombre: selected.nombre,
                          direccion: selected.direccion,
                          comuna: selected.comuna
                        })
                      }
                    }
                  }}
                >
                  <SelectTrigger className="w-full max-w-md">
                    <SelectValue placeholder="Seleccionar condominio" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los condominios</SelectItem>
                    {condominios.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.nombre}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Header con estadísticas */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-muted-foreground">Total</p>
                <p className="text-xl sm:text-2xl font-bold">{stats.total}</p>
              </div>
              <ClipboardCheck className="w-6 h-6 sm:w-8 sm:h-8 text-blue-500 hidden sm:block" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-muted-foreground">Planificadas</p>
                <p className="text-xl sm:text-2xl font-bold text-gray-600">{stats.planificadas}</p>
              </div>
              <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-gray-500 hidden sm:block" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-muted-foreground">En Ejecución</p>
                <p className="text-xl sm:text-2xl font-bold text-blue-600">{stats.enEjecucion}</p>
              </div>
              <ClipboardCheck className="w-6 h-6 sm:w-8 sm:h-8 text-blue-500 hidden sm:block" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-muted-foreground">Completadas</p>
                <p className="text-xl sm:text-2xl font-bold text-green-600">{stats.completadas}</p>
              </div>
              <CheckCircle className="w-6 h-6 sm:w-8 sm:h-8 text-green-500 hidden sm:block" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-muted-foreground">Puntuación</p>
                <p className="text-xl sm:text-2xl font-bold">{stats.promedioPuntuacion}%</p>
              </div>
              <Target className="w-6 h-6 sm:w-8 sm:h-8 text-amber-500 hidden sm:block" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lista de auditorías */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <CardTitle>Auditorías</CardTitle>
                <CardDescription>Gestión de auditorías según Ley 21.442</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={exportCSV} disabled={filteredAuditorias.length === 0}>
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  CSV
                </Button>
                <Button variant="outline" size="sm" onClick={exportPDF} disabled={filteredAuditorias.length === 0}>
                  <Printer className="w-4 h-4 mr-2" />
                  Imprimir
                </Button>
                <Button size="sm" onClick={() => { resetForm(); setDialogOpen(true) }}>
                  <Plus className="w-4 h-4 mr-2" />
                  Nueva
                </Button>
              </div>
            </div>
            {/* Filtros */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar auditorías..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterEstado} onValueChange={setFilterEstado}>
                <SelectTrigger className="w-full sm:w-[160px]">
                  <SelectValue placeholder="Estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {ESTADOS_AUDITORIA.map(est => (
                    <SelectItem key={est.value} value={est.value}>{est.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterTipo} onValueChange={setFilterTipo}>
                <SelectTrigger className="w-full sm:w-[160px]">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {TIPOS_AUDITORIA.map(tipo => (
                    <SelectItem key={tipo.value} value={tipo.value}>{tipo.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Vista móvil: Cards */}
          <div className="md:hidden space-y-3">
            {filteredAuditorias.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No hay auditorías registradas
              </div>
            ) : (
              filteredAuditorias.map((auditoria) => (
                <Card key={auditoria.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-sm font-medium">{auditoria.codigo}</span>
                          {getEstadoBadge(auditoria.estado)}
                        </div>
                        <p className="font-medium truncate">{auditoria.titulo}</p>
                        <div className="flex items-center gap-2 mt-2">
                          {getTipoBadge(auditoria.tipo)}
                          <div className="flex items-center gap-1">
                            <Progress value={auditoria.puntuacionTotal} className="w-12 h-2" />
                            <span className="text-xs">{auditoria.puntuacionTotal}%</span>
                          </div>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="shrink-0">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewDetail(auditoria)}>
                            <Eye className="w-4 h-4 mr-2" />
                            Ver Detalle
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateEstado(auditoria.id, 'En Ejecución')}>
                            <ClipboardCheck className="w-4 h-4 mr-2" />
                            Iniciar
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateEstado(auditoria.id, 'Completada')}>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Completar
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            className="text-red-600"
                            onClick={() => handleDelete(auditoria.id)}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Eliminar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Vista desktop: Tabla */}
          <div className="hidden md:block rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Título</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Puntuación</TableHead>
                  <TableHead>Fecha</TableHead>
                  <TableHead className="w-[80px]">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAuditorias.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No hay auditorías registradas
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredAuditorias.map((auditoria) => (
                    <TableRow key={auditoria.id}>
                      <TableCell className="font-mono font-medium">{auditoria.codigo}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{auditoria.titulo}</p>
                          <p className="text-xs text-muted-foreground">{auditoria.categoria}</p>
                        </div>
                      </TableCell>
                      <TableCell>{getTipoBadge(auditoria.tipo)}</TableCell>
                      <TableCell>{getEstadoBadge(auditoria.estado)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={auditoria.puntuacionTotal} className="w-16 h-2" />
                          <span className="text-sm">{auditoria.puntuacionTotal}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {auditoria.fechaInicio 
                          ? new Date(auditoria.fechaInicio).toLocaleDateString('es-CL')
                          : '-'
                        }
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewDetail(auditoria)}>
                              <Eye className="w-4 h-4 mr-2" />
                              Ver Detalle
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleUpdateEstado(auditoria.id, 'En Ejecución')}>
                              <ClipboardCheck className="w-4 h-4 mr-2" />
                              Iniciar Auditoría
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleUpdateEstado(auditoria.id, 'Completada')}>
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Completar
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="text-red-600"
                              onClick={() => handleDelete(auditoria.id)}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Eliminar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialog para crear auditoría */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nueva Auditoría</DialogTitle>
            <DialogDescription>
              Planifique una nueva auditoría
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4">
              <div className="col-span-full">
                <Label htmlFor="titulo">Título de la Auditoría *</Label>
                <Input
                  id="titulo"
                  value={formData.titulo}
                  onChange={(e) => setFormData({ ...formData, titulo: e.target.value })}
                  placeholder="Ej: Auditoría Semestral 2024"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="tipo">Tipo de Auditoría</Label>
                <Select value={formData.tipo} onValueChange={(v) => setFormData({ ...formData, tipo: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TIPOS_AUDITORIA.map(t => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="categoria">Categoría</Label>
                <Select value={formData.categoria} onValueChange={(v) => setFormData({ ...formData, categoria: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIAS_AUDITORIA.map(c => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="fechaInicio">Fecha de Inicio</Label>
                <Input
                  id="fechaInicio"
                  type="date"
                  value={formData.fechaInicio}
                  onChange={(e) => setFormData({ ...formData, fechaInicio: e.target.value })}
                />
              </div>
              
              <div>
                <Label htmlFor="fechaFin">Fecha de Término</Label>
                <Input
                  id="fechaFin"
                  type="date"
                  value={formData.fechaFin}
                  onChange={(e) => setFormData({ ...formData, fechaFin: e.target.value })}
                />
              </div>
              
              <div className="col-span-full">
                <Label htmlFor="responsable">Auditor Responsable</Label>
                <Input
                  id="responsable"
                  value={formData.responsable}
                  onChange={(e) => setFormData({ ...formData, responsable: e.target.value })}
                  placeholder="Nombre del auditor responsable"
                />
              </div>
              
              <div className="col-span-full">
                <Label htmlFor="alcance">Alcance</Label>
                <Textarea
                  id="alcance"
                  value={formData.alcance}
                  onChange={(e) => setFormData({ ...formData, alcance: e.target.value })}
                  placeholder="Describa el alcance de la auditoría..."
                  rows={2}
                />
              </div>
              
              <div className="col-span-full">
                <Label htmlFor="objetivo">Objetivo</Label>
                <Textarea
                  id="objetivo"
                  value={formData.objetivo}
                  onChange={(e) => setFormData({ ...formData, objetivo: e.target.value })}
                  placeholder="Objetivo de la auditoría..."
                  rows={2}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">
                Crear Auditoría
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog de detalle de auditoría */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base sm:text-lg">
              {selectedAuditoria?.codigo} - {selectedAuditoria?.titulo}
            </DialogTitle>
            <DialogDescription>
              {getEstadoBadge(selectedAuditoria?.estado || 'Planificada')}
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="checklist" className="flex-1">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="checklist" className="text-xs sm:text-sm">Checklist</TabsTrigger>
              <TabsTrigger value="hallazgos" className="text-xs sm:text-sm">Hallazgos</TabsTrigger>
              <TabsTrigger value="acciones" className="text-xs sm:text-sm">Acciones</TabsTrigger>
              <TabsTrigger value="resumen" className="text-xs sm:text-sm">Resumen</TabsTrigger>
            </TabsList>
            
            <ScrollArea className="h-[55vh]">
              {/* Tab: Checklist */}
              <TabsContent value="checklist" className="p-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-4">
                  <h3 className="font-semibold">Lista de Verificación</h3>
                  <div className="flex items-center gap-4 text-sm">
                    <span>
                      Conformes: {selectedAuditoria?.items?.filter(i => i.calificacion === 'Conforme').length || 0}
                    </span>
                    <span>
                      No Conformes: {selectedAuditoria?.items?.filter(i => i.calificacion === 'No Conforme').length || 0}
                    </span>
                  </div>
                </div>
                
                {selectedAuditoria?.items?.map((item) => (
                  <Card key={item.id} className="mb-2">
                    <CardContent className="p-3">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-2 mb-1">
                            <Badge variant="outline" className="text-xs">{item.seccion}</Badge>
                            {item.obligatorio && (
                              <Badge variant="destructive" className="text-xs">Obligatorio</Badge>
                            )}
                          </div>
                          <p className="font-medium text-sm">{item.pregunta}</p>
                          {item.observaciones && (
                            <p className="text-xs text-muted-foreground mt-1">{item.observaciones}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Select
                            value={item.calificacion || 'Pendiente'}
                            onValueChange={(v) => handleUpdateItem(item.id, { 
                              calificacion: v,
                              cumple: v === 'Conforme'
                            })}
                          >
                            <SelectTrigger className="w-28 sm:w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Conforme">Conforme</SelectItem>
                              <SelectItem value="No Conforme">No Conforme</SelectItem>
                              <SelectItem value="N/A">No Aplica</SelectItem>
                              <SelectItem value="Pendiente">Pendiente</SelectItem>
                            </SelectContent>
                          </Select>
                          <Select
                            value={item.criticidad || 'Menor'}
                            onValueChange={(v) => handleUpdateItem(item.id, { criticidad: v })}
                          >
                            <SelectTrigger className="w-20 sm:w-24">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Crítica">Crítica</SelectItem>
                              <SelectItem value="Mayor">Mayor</SelectItem>
                              <SelectItem value="Menor">Menor</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              
              {/* Tab: Hallazgos */}
              <TabsContent value="hallazgos" className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-semibold">Hallazgos y Observaciones</h3>
                  <Button size="sm" onClick={() => {
                    setHallazgoForm({
                      ...hallazgoForm,
                      codigo: `H-${(selectedAuditoria?.hallazgos?.length || 0) + 1}`
                    })
                    setHallazgoDialogOpen(true)
                  }}>
                    <Plus className="w-4 h-4 mr-2" />
                    Nuevo
                  </Button>
                </div>
                
                {selectedAuditoria?.hallazgos?.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No hay hallazgos registrados</p>
                ) : (
                  <div className="space-y-3">
                    {selectedAuditoria?.hallazgos?.map((hallazgo) => (
                      <Card key={hallazgo.id}>
                        <CardContent className="p-4">
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                            <div>
                              <div className="flex flex-wrap items-center gap-2 mb-1">
                                <span className="font-mono text-sm">{hallazgo.codigo}</span>
                                {getCriticidadBadge(hallazgo.criticidad)}
                                <Badge variant="outline" className="text-xs">{hallazgo.tipo}</Badge>
                              </div>
                              <p className="font-medium">{hallazgo.titulo}</p>
                              <p className="text-sm text-muted-foreground">{hallazgo.descripcion}</p>
                            </div>
                            <Badge className="shrink-0">{hallazgo.estado}</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              {/* Tab: Acciones */}
              <TabsContent value="acciones" className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-semibold">Acciones Correctivas y Preventivas</h3>
                  <Button size="sm" onClick={() => {
                    setAccionForm({
                      ...accionForm,
                      codigo: `AC-${(selectedAuditoria?.acciones?.length || 0) + 1}`
                    })
                    setAccionDialogOpen(true)
                  }}>
                    <Plus className="w-4 h-4 mr-2" />
                    Nueva
                  </Button>
                </div>
                
                {selectedAuditoria?.acciones?.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No hay acciones registradas</p>
                ) : (
                  <div className="space-y-3">
                    {selectedAuditoria?.acciones?.map((accion) => (
                      <Card key={accion.id}>
                        <CardContent className="p-4">
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                            <div>
                              <div className="flex flex-wrap items-center gap-2 mb-1">
                                <span className="font-mono text-sm">{accion.codigo}</span>
                                <Badge variant="outline" className="text-xs">{accion.tipo}</Badge>
                              </div>
                              <p className="font-medium">{accion.titulo}</p>
                              <p className="text-sm text-muted-foreground">{accion.descripcion}</p>
                              {accion.responsable && (
                                <p className="text-xs mt-1">Responsable: {accion.responsable}</p>
                              )}
                            </div>
                            <Badge className="shrink-0">{accion.estado}</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              {/* Tab: Resumen */}
              <TabsContent value="resumen" className="p-4">
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <p className="text-xs sm:text-sm text-muted-foreground">Puntuación Total</p>
                      <p className="text-2xl sm:text-3xl font-bold">{selectedAuditoria?.puntuacionTotal}%</p>
                      <Progress value={selectedAuditoria?.puntuacionTotal || 0} className="mt-2" />
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <p className="text-xs sm:text-sm text-muted-foreground">Hallazgos</p>
                      <p className="text-2xl sm:text-3xl font-bold">{selectedAuditoria?.hallazgos?.length || 0}</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <p className="text-xs sm:text-sm text-muted-foreground">Acciones</p>
                      <p className="text-2xl sm:text-3xl font-bold">{selectedAuditoria?.acciones?.length || 0}</p>
                    </CardContent>
                  </Card>
                </div>
                
                {selectedAuditoria?.conclusiones && (
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">Conclusiones</h4>
                    <p className="text-sm text-muted-foreground">{selectedAuditoria.conclusiones}</p>
                  </div>
                )}
                
                {selectedAuditoria?.alcance && (
                  <div>
                    <h4 className="font-semibold mb-2">Alcance</h4>
                    <p className="text-sm text-muted-foreground">{selectedAuditoria.alcance}</p>
                  </div>
                )}
              </TabsContent>
            </ScrollArea>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Dialog para crear hallazgo */}
      <Dialog open={hallazgoDialogOpen} onOpenChange={setHallazgoDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Registrar Hallazgo</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateHallazgo}>
            <div className="space-y-4 py-4">
              <div>
                <Label>Código</Label>
                <Input value={hallazgoForm.codigo} disabled />
              </div>
              <div>
                <Label>Título *</Label>
                <Input
                  value={hallazgoForm.titulo}
                  onChange={(e) => setHallazgoForm({ ...hallazgoForm, titulo: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label>Descripción *</Label>
                <Textarea
                  value={hallazgoForm.descripcion}
                  onChange={(e) => setHallazgoForm({ ...hallazgoForm, descripcion: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Tipo</Label>
                  <Select value={hallazgoForm.tipo} onValueChange={(v) => setHallazgoForm({ ...hallazgoForm, tipo: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Observación">Observación</SelectItem>
                      <SelectItem value="No Conformidad">No Conformidad</SelectItem>
                      <SelectItem value="No Conformidad Mayor">No Conformidad Mayor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Criticidad</Label>
                  <Select value={hallazgoForm.criticidad} onValueChange={(v) => setHallazgoForm({ ...hallazgoForm, criticidad: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Crítica">Crítica</SelectItem>
                      <SelectItem value="Mayor">Mayor</SelectItem>
                      <SelectItem value="Menor">Menor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label>Área Afectada</Label>
                <Input
                  value={hallazgoForm.area}
                  onChange={(e) => setHallazgoForm({ ...hallazgoForm, area: e.target.value })}
                />
              </div>
              <div>
                <Label>Fecha Límite</Label>
                <Input
                  type="date"
                  value={hallazgoForm.fechaLimite}
                  onChange={(e) => setHallazgoForm({ ...hallazgoForm, fechaLimite: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setHallazgoDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">Registrar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog para crear acción */}
      <Dialog open={accionDialogOpen} onOpenChange={setAccionDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Crear Acción Correctiva/Preventiva</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateAccion}>
            <div className="space-y-4 py-4">
              <div>
                <Label>Código</Label>
                <Input value={accionForm.codigo} disabled />
              </div>
              <div>
                <Label>Título *</Label>
                <Input
                  value={accionForm.titulo}
                  onChange={(e) => setAccionForm({ ...accionForm, titulo: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label>Descripción *</Label>
                <Textarea
                  value={accionForm.descripcion}
                  onChange={(e) => setAccionForm({ ...accionForm, descripcion: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Tipo</Label>
                  <Select value={accionForm.tipo} onValueChange={(v) => setAccionForm({ ...accionForm, tipo: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Correctiva">Correctiva</SelectItem>
                      <SelectItem value="Preventiva">Preventiva</SelectItem>
                      <SelectItem value="Mejora">Mejora</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Responsable</Label>
                  <Input
                    value={accionForm.responsable}
                    onChange={(e) => setAccionForm({ ...accionForm, responsable: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label>Fecha Compromiso</Label>
                <Input
                  type="date"
                  value={accionForm.fechaCompromiso}
                  onChange={(e) => setAccionForm({ ...accionForm, fechaCompromiso: e.target.value })}
                />
              </div>
              {selectedAuditoria?.hallazgos && selectedAuditoria.hallazgos.length > 0 && (
                <div>
                  <Label>Relacionado con Hallazgo</Label>
                  <Select value={accionForm.hallazgoId || 'ninguno'} onValueChange={(v) => setAccionForm({ ...accionForm, hallazgoId: v === 'ninguno' ? '' : v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ninguno">Ninguno</SelectItem>
                      {selectedAuditoria.hallazgos.map((h) => (
                        <SelectItem key={h.id} value={h.id}>{h.codigo} - {h.titulo}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setAccionDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">Crear</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
