import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const modulo = searchParams.get('modulo') || 'residentes'
    const fechaDesde = searchParams.get('fechaDesde')
    const fechaHasta = searchParams.get('fechaHasta')
    const estado = searchParams.get('estado')
    const tipo = searchParams.get('tipo')
    const categoria = searchParams.get('categoria')
    const prioridad = searchParams.get('prioridad')
    const contrato = searchParams.get('contrato')
    const espacio = searchParams.get('espacio')
    const frecuencia = searchParams.get('frecuencia')
    const tipoGasto = searchParams.get('tipoGasto')

    let datos: any[] = []

    switch (modulo) {
      case 'residentes': {
        const where: any = {}
        if (estado) where.estado = estado
        if (tipo) where.tipo = tipo
        
        datos = await db.residente.findMany({
          where,
          select: {
            id: true,
            nombre: true,
            apellido: true,
            rut: true,
            unidad: true,
            etapa: true,
            tipo: true,
            telefono: true,
            email: true,
            fechaIngreso: true,
            estado: true,
            vehiculos: true,
            notas: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'personal': {
        const where: any = {}
        if (estado) where.estado = estado
        if (contrato) where.contrato = contrato
        
        datos = await db.personal.findMany({
          where,
          select: {
            id: true,
            nombre: true,
            rut: true,
            cargo: true,
            contrato: true,
            afp: true,
            salud: true,
            mutual: true,
            ccaf: true,
            fechaIngreso: true,
            sueldoBase: true,
            movilizacion: true,
            colacion: true,
            viatico: true,
            asigFamiliar: true,
            estado: true,
            email: true,
            telefono: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'ot': {
        const where: any = {}
        if (estado) where.estado = estado
        if (tipo) where.tipo = tipo
        if (prioridad) where.prioridad = prioridad
        
        datos = await db.ordenTrabajo.findMany({
          where,
          select: {
            id: true,
            otNum: true,
            titulo: true,
            tipo: true,
            prioridad: true,
            estado: true,
            ubicacion: true,
            fechaInicio: true,
            fechaLimite: true,
            fechaInicioReal: true,
            fechaFinReal: true,
            costoEstimado: true,
            costoReal: true,
            progreso: true,
            descripcion: true,
            tiempoEst: true,
            tiempoReal: true,
            valorHora: true,
            estadoAprobacion: true,
            formaPago: true,
            esRecurrente: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'proyectos': {
        const where: any = {}
        if (estado) where.estado = estado
        if (categoria) where.categoria = categoria
        
        datos = await db.proyecto.findMany({
          where,
          select: {
            id: true,
            nombre: true,
            categoria: true,
            estado: true,
            ubicacion: true,
            fechaInicio: true,
            fechaFin: true,
            presProg: true,
            presUsado: true,
            avance: true,
            descripcion: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'gastos': {
        const where: any = {}
        if (estado) where.estado = estado
        if (categoria) where.categoria = categoria
        
        datos = await db.gasto.findMany({
          where,
          select: {
            id: true,
            descripcion: true,
            categoria: true,
            estado: true,
            monto: true,
            fecha: true,
            propiedad: true,
            nDoc: true,
            notas: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'gastoscomunes': {
        const where: any = {}
        if (estado) where.estado = estado
        
        datos = await db.gastoComun.findMany({
          where,
          select: {
            id: true,
            periodo: true,
            fechaEmision: true,
            fechaVencimiento: true,
            estado: true,
            totalGastos: true,
            totalCobrar: true,
            montoPorUnidad: true,
            notas: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'morosidad': {
        // Obtener residentes con estado Moroso
        const where: any = {}
        if (estado) where.estado = estado
        else where.estado = 'Moroso'
        
        datos = await db.residente.findMany({
          where: { estado: 'Moroso' },
          select: {
            id: true,
            nombre: true,
            apellido: true,
            rut: true,
            unidad: true,
            etapa: true,
            tipo: true,
            telefono: true,
            email: true,
            estado: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'activos': {
        const where: any = {}
        if (estado) where.estado = estado
        if (categoria) where.categoria = categoria
        
        datos = await db.activo.findMany({
          where,
          select: {
            id: true,
            nombre: true,
            categoria: true,
            estado: true,
            ubicacion: true,
            serie: true,
            fechaCompra: true,
            costoCompra: true,
            valorActual: true,
            descripcion: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'inventario': {
        const where: any = {}
        if (categoria) where.categoria = categoria
        
        datos = await db.catMaterial.findMany({
          where,
          select: {
            id: true,
            codigo: true,
            nombre: true,
            unidad: true,
            precioUnit: true,
            categoria: true,
            stockMinimo: true,
            stockActual: true,
            ubicacion: true,
            descripcion: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'materiales': {
        const where: any = {}
        if (categoria) where.categoria = categoria
        
        datos = await db.catMaterial.findMany({
          where,
          select: {
            id: true,
            codigo: true,
            nombre: true,
            unidad: true,
            precioUnit: true,
            categoria: true,
            stockMinimo: true,
            stockActual: true,
            ubicacion: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'herramientas': {
        const where: any = {}
        if (estado) where.estado = estado
        
        datos = await db.catHerramienta.findMany({
          where,
          select: {
            id: true,
            codigo: true,
            nombre: true,
            marca: true,
            modelo: true,
            cantidad: true,
            ubicacion: true,
            estado: true,
            valorReposicion: true,
            fechaAdquisicion: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'tareas': {
        const where: any = {}
        if (categoria) where.categoria = categoria
        if (frecuencia) where.frecuencia = frecuencia
        
        datos = await db.catTarea.findMany({
          where,
          select: {
            id: true,
            codigo: true,
            nombre: true,
            categoria: true,
            sistema: true,
            tipoMantencion: true,
            frecuencia: true,
            responsable: true,
            tiempoEstimado: true,
            descripcion: true,
            esRecurrente: true,
            activa: true,
            proximaEjecucion: true,
            ultimaEjecucion: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'proveedores': {
        const where: any = {}
        if (estado) where.estado = estado
        
        datos = await db.proveedor.findMany({
          where,
          select: {
            id: true,
            razonSocial: true,
            rut: true,
            giro: true,
            direccion: true,
            comuna: true,
            telCorp: true,
            emailCorp: true,
            web: true,
            contacto: true,
            cargo: true,
            telDirecto: true,
            emailContacto: true,
            celular: true,
            estado: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'reservas': {
        const where: any = {}
        if (estado) where.estado = estado
        if (espacio) where.espacio = espacio
        
        datos = await db.reserva.findMany({
          where,
          select: {
            id: true,
            titulo: true,
            espacio: true,
            fecha: true,
            horaInicio: true,
            horaFin: true,
            residente: true,
            unidad: true,
            telefono: true,
            email: true,
            numPersonas: true,
            estado: true,
            monto: true,
            pagado: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'asistencia': {
        const where: any = {}
        if (estado) where.estado = estado
        
        datos = await db.asistencia.findMany({
          where,
          select: {
            id: true,
            fecha: true,
            horaEntrada: true,
            horaSalida: true,
            estado: true,
            observaciones: true,
            personal: {
              select: {
                nombre: true,
                cargo: true
              }
            }
          },
          orderBy: { createdAt: 'desc' }
        })
        // Flatten the data
        datos = datos.map(a => ({
          ...a,
          personalNombre: a.personal?.nombre || '-',
          personalCargo: a.personal?.cargo || '-'
        }))
        break
      }

      case 'cumplimiento': {
        const where: any = {}
        if (estado) where.estado = estado
        if (categoria) where.categoria = categoria
        
        datos = await db.cumplimiento.findMany({
          where,
          select: {
            id: true,
            titulo: true,
            categoria: true,
            subcategoria: true,
            descripcion: true,
            obligatorio: true,
            fechaVencimiento: true,
            fechaRecordatorio: true,
            estado: true,
            documentoNombre: true,
            notas: true,
            cumplimientoPorc: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'auditoria': {
        const where: any = {}
        if (estado) where.estado = estado
        if (tipo) where.tipo = tipo
        
        datos = await db.auditoria.findMany({
          where,
          select: {
            id: true,
            codigo: true,
            titulo: true,
            tipo: true,
            categoria: true,
            estado: true,
            fechaInicio: true,
            fechaFin: true,
            fechaInforme: true,
            alcance: true,
            objetivo: true,
            responsable: true,
            conclusiones: true,
            puntuacionTotal: true,
            itemsCriticos: true,
            itemsMayores: true,
            itemsMenores: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      case 'rondas': {
        const where: any = {}
        if (estado) where.estado = estado
        
        datos = await db.registroRonda.findMany({
          where,
          select: {
            id: true,
            fechaHora: true,
            ubicacion: true,
            observaciones: true,
            estado: true,
            notaIncidencia: true,
            usuarioNombre: true,
            punto: {
              select: {
                nombre: true,
                ubicacion: true
              }
            }
          },
          orderBy: { fechaHora: 'desc' }
        })
        // Flatten the data
        datos = datos.map(r => ({
          ...r,
          puntoNombre: r.punto?.nombre || '-',
          puntoUbicacion: r.punto?.ubicacion || '-'
        }))
        break
      }

      case 'centrocostos': {
        const where: any = {}
        if (estado) where.estado = estado
        if (tipoGasto) where.tipoGasto = tipoGasto
        
        datos = await db.centroCostoMaster.findMany({
          where,
          select: {
            id: true,
            codigo: true,
            nombre: true,
            descripcion: true,
            responsable: true,
            tipoGasto: true,
            presupuestoMens: true,
            presupuestoAnual: true,
            estado: true
          },
          orderBy: { createdAt: 'desc' }
        })
        break
      }

      default:
        datos = []
    }

    // Apply date filters if provided
    if (fechaDesde || fechaHasta) {
      datos = datos.filter((item: any) => {
        const fechaCampo = item.fecha || item.fechaHora || item.fechaInicio || item.fechaEmision || item.createdAt
        if (!fechaCampo) return true
        
        const fecha = new Date(fechaCampo)
        if (fechaDesde && fecha < new Date(fechaDesde)) return false
        if (fechaHasta && fecha > new Date(fechaHasta)) return false
        return true
      })
    }

    return NextResponse.json(datos)
  } catch (error) {
    console.error('Error en reportes:', error)
    return NextResponse.json({ error: 'Error al obtener datos' }, { status: 500 })
  }
}
