'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Download, FileArchive, FolderOpen, CheckCircle2, ArrowRight, Home } from 'lucide-react'
import Link from 'next/link'

const archivos = [
  {
    nombre: 'static-landing.zip',
    descripcion: 'Landing Page Estática',
    tamaño: '1.3 MB',
    contenido: ['index.html', 'logo.png', 'images/ (4 imágenes)'],
    uso: 'Para subir a tu hosting actual (cPanel)',
    color: 'bg-green-500'
  },
  {
    nombre: 'proyecto-completo.zip',
    descripcion: 'Sistema Completo',
    tamaño: '1.7 MB',
    contenido: ['src/', 'prisma/', 'public/', 'package.json', 'next.config.ts'],
    uso: 'Para subir a Vercel (sistema de gestión)',
    color: 'bg-blue-500'
  }
]

export default function DescargasPage() {
  const [downloading, setDownloading] = useState<string | null>(null)

  const handleDownload = async (filename: string) => {
    setDownloading(filename)
    try {
      const response = await fetch(`/api/download/${filename}`)
      if (!response.ok) throw new Error('Error al descargar')
      
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error('Error:', error)
      alert('Error al descargar el archivo')
    } finally {
      setDownloading(null)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-black rounded-lg flex items-center justify-center overflow-hidden">
              <img src="/logo.png" alt="CYJ" className="w-8 h-8 object-contain" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900">Asesorías Integrales CYJ</h1>
              <p className="text-xs text-slate-500">Centro de Descargas</p>
            </div>
          </div>
          <Link href="/">
            <Button variant="outline" size="sm">
              <Home className="w-4 h-4 mr-2" />
              Volver al inicio
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <Badge className="mb-4 bg-blue-100 text-blue-700">Descargas Disponibles</Badge>
          <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-2">
            Archivos para Publicar tu Sitio Web
          </h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Descarga los archivos necesarios para subir tu landing page al hosting 
            y el sistema completo a Vercel.
          </p>
        </div>

        {/* Download Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {archivos.map((archivo) => (
            <Card key={archivo.nombre} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className={`h-2 ${archivo.color}`} />
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
                      <FileArchive className="w-6 h-6 text-slate-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{archivo.descripcion}</CardTitle>
                      <p className="text-sm text-slate-500 font-mono">{archivo.nombre}</p>
                    </div>
                  </div>
                  <Badge variant="outline">{archivo.tamaño}</Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-2">
                <div className="mb-4">
                  <p className="text-sm font-medium text-slate-700 mb-2">Contenido:</p>
                  <ul className="space-y-1">
                    {archivo.contenido.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-slate-600">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        <code className="bg-slate-100 px-1.5 py-0.5 rounded text-xs">{item}</code>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-blue-50 p-3 rounded-lg mb-4">
                  <p className="text-sm text-blue-700">
                    <strong>Uso:</strong> {archivo.uso}
                  </p>
                </div>
                
                <Button 
                  className="w-full"
                  onClick={() => handleDownload(archivo.nombre)}
                  disabled={downloading === archivo.nombre}
                >
                  {downloading === archivo.nombre ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Descargando...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Descargar {archivo.tamaño}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Instructions */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-blue-600" />
              ¿Qué hacer después de descargar?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-semibold text-slate-900">Landing Page (static-landing.zip)</h4>
                <ol className="space-y-2 text-sm text-slate-600">
                  <li className="flex gap-2">
                    <span className="bg-green-100 text-green-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
                    Descomprime el archivo ZIP
                  </li>
                  <li className="flex gap-2">
                    <span className="bg-green-100 text-green-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
                    Entra a tu cPanel - Administrador de Archivos
                  </li>
                  <li className="flex gap-2">
                    <span className="bg-green-100 text-green-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
                    Sube todos los archivos a public_html
                  </li>
                  <li className="flex gap-2">
                    <span className="bg-green-100 text-green-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0">4</span>
                    Visita tu dominio y listo!
                  </li>
                </ol>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-semibold text-slate-900">Sistema (proyecto-completo.zip)</h4>
                <ol className="space-y-2 text-sm text-slate-600">
                  <li className="flex gap-2">
                    <span className="bg-blue-100 text-blue-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
                    Sube el proyecto a GitHub
                  </li>
                  <li className="flex gap-2">
                    <span className="bg-blue-100 text-blue-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
                    Crea cuenta gratis en vercel.com
                  </li>
                  <li className="flex gap-2">
                    <span className="bg-blue-100 text-blue-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
                    Importa tu repositorio de GitHub
                  </li>
                  <li className="flex gap-2">
                    <span className="bg-blue-100 text-blue-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0">4</span>
                    El sistema estará disponible online!
                  </li>
                </ol>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-amber-50 rounded-lg border border-amber-200">
              <p className="text-sm text-amber-800">
                <strong>Importante:</strong> El sistema de gestión requiere Vercel (gratis) o un servidor VPS. 
                Tu hosting compartido NO soporta Node.js/Next.js.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Quick Links */}
        <div className="mt-8 text-center">
          <p className="text-sm text-slate-500 mb-3">Enlaces útiles:</p>
          <div className="flex flex-wrap justify-center gap-3">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="sm">
                Crear cuenta GitHub
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </a>
            <a href="https://vercel.com" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="sm">
                Crear cuenta Vercel
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </a>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-6 mt-12">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <p className="text-sm text-slate-400">
            © {new Date().getFullYear()} Asesorías Integrales CYJ. Todos los derechos reservados.
          </p>
        </div>
      </footer>
    </div>
  )
}
