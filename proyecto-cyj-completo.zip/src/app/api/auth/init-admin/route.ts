/**
 * API para crear el usuario administrador inicial
 * Condominio Laguna Norte - Sistema de Gestión v2
 * 
 * NOTA: Este endpoint debe ser deshabilitado en producción
 * El administrador debe ser creado manualmente o mediante un script seguro
 */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, generateSecurePassword } from '@/lib/auth'

export async function POST(request: Request) {
  try {
    // Verificar si ya existe algún usuario administrador
    const existingAdmin = await db.user.findFirst({
      where: { rol: 'admin' }
    })
    
    if (existingAdmin) {
      return NextResponse.json({ 
        message: 'Ya existe un usuario administrador en el sistema',
        error: 'ADMIN_EXISTS'
      }, { status: 400 })
    }
    
    // Verificar si hay usuarios en el sistema
    const userCount = await db.user.count()
    if (userCount > 0) {
      return NextResponse.json({ 
        message: 'El sistema ya tiene usuarios configurados',
        error: 'SYSTEM_CONFIGURED'
      }, { status: 400 })
    }
    
    // Generar contraseña segura aleatoria
    const securePassword = generateSecurePassword(16)
    const hashedPassword = await hashPassword(securePassword)
    
    // Crear usuario administrador con datos genéricos
    // El administrador debe cambiar estos datos inmediatamente
    const admin = await db.user.create({
      data: {
        email: 'admin@localhost',
        nombre: 'Administrador',
        apellido: 'Sistema',
        password: hashedPassword,
        rol: 'admin',
        activo: true,
        emailVerificado: new Date(),
        permisos: JSON.stringify({
          // Permisos completos para admin
          'usuarios.ver': true, 'usuarios.crear': true, 'usuarios.editar': true, 'usuarios.eliminar': true,
          'residentes.ver': true, 'residentes.crear': true, 'residentes.editar': true, 'residentes.eliminar': true,
          'propiedades.ver': true, 'propiedades.crear': true, 'propiedades.editar': true, 'propiedades.eliminar': true,
          'personal.ver': true, 'personal.crear': true, 'personal.editar': true, 'personal.eliminar': true,
          'proveedores.ver': true, 'proveedores.crear': true, 'proveedores.editar': true, 'proveedores.eliminar': true,
          'ots.ver': true, 'ots.crear': true, 'ots.editar': true, 'ots.eliminar': true, 'ots.aprobar': true,
          'proyectos.ver': true, 'proyectos.crear': true, 'proyectos.editar': true, 'proyectos.eliminar': true,
          'gastos.ver': true, 'gastos.crear': true, 'gastos.editar': true, 'gastos.eliminar': true, 'gastos.aprobar': true,
          'inspecciones.ver': true, 'inspecciones.crear': true, 'inspecciones.editar': true, 'inspecciones.eliminar': true,
          'activos.ver': true, 'activos.crear': true, 'activos.editar': true, 'activos.eliminar': true,
          'catalogos.ver': true, 'catalogos.crear': true, 'catalogos.editar': true, 'catalogos.eliminar': true,
          'centros-costo.ver': true, 'centros-costo.crear': true, 'centros-costo.editar': true, 'centros-costo.eliminar': true,
          'reportes.ver': true, 'reportes.exportar': true,
          'configuracion.ver': true, 'configuracion.editar': true,
          'logs.ver': true,
          'inventario.ver': true, 'inventario.editar': true,
        })
      }
    })
    
    // IMPORTANTE: En producción, esta contraseña debe enviarse por un canal seguro
    // y el endpoint debe ser eliminado o protegido adicionalmente
    console.log('='.repeat(60))
    console.log('USUARIO ADMINISTRADOR CREADO')
    console.log('Email:', admin.email)
    console.log('Contraseña temporal:', securePassword)
    console.log('CAMBIE ESTAS CREDENCIALES INMEDIATAMENTE')
    console.log('='.repeat(60))
    
    return NextResponse.json({ 
      message: 'Usuario administrador creado exitosamente',
      warning: 'DEBE CAMBIAR LAS CREDENCIALES INMEDIATAMENTE',
      user: {
        id: admin.id,
        email: admin.email,
        nombre: admin.nombre,
        rol: admin.rol
      },
      // Solo mostrar la contraseña en la respuesta para configuración inicial
      // En producción, esto debe enviarse por email seguro u otro canal
      tempPassword: securePassword
    })
    
  } catch (error) {
    console.error('Error creando admin:', error)
    return NextResponse.json({ 
      error: 'Error al crear usuario administrador',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
