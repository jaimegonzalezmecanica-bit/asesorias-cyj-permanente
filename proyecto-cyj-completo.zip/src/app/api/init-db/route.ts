import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * API para inicializar la base de datos en producción
 * Visitar: /api/init-db para crear el usuario admin inicial
 */
export async function GET() {
  try {
    // Verificar si ya existe un usuario admin
    const existingAdmin = await db.user.findUnique({
      where: { email: 'admin@cyjcondominios.cl' }
    })

    if (existingAdmin) {
      return NextResponse.json({ 
        success: true, 
        message: 'La base de datos ya está inicializada',
        adminExists: true,
        email: existingAdmin.email
      })
    }

    // Crear usuario admin inicial
    const bcrypt = await import('bcrypt')
    const hashedPassword = await bcrypt.hash('admin123', 10)
    
    const user = await db.user.create({
      data: {
        email: 'admin@cyjcondominios.cl',
        nombre: 'Administrador',
        apellido: 'Sistema',
        password: hashedPassword,
        rol: 'admin',
        activo: true,
        permisos: JSON.stringify({
          usuarios: ['crear', 'editar', 'eliminar', 'ver'],
          condominios: ['crear', 'editar', 'eliminar', 'ver'],
          personal: ['crear', 'editar', 'eliminar', 'ver'],
          residentes: ['crear', 'editar', 'eliminar', 'ver'],
          ordenes: ['crear', 'editar', 'eliminar', 'ver'],
          gastos: ['crear', 'editar', 'eliminar', 'ver'],
          proyectos: ['crear', 'editar', 'eliminar', 'ver'],
          reportes: ['ver'],
          configuracion: ['editar', 'ver'],
        })
      }
    })

    // Crear caja chica inicial
    await db.cajaChica.create({
      data: {
        saldo: 0,
        saldoInicial: 0
      }
    })

    return NextResponse.json({ 
      success: true, 
      message: 'Base de datos inicializada correctamente',
      adminCreated: {
        email: user.email,
        nombre: user.nombre,
        rol: user.rol
      },
      credentials: {
        email: 'admin@cyjcondominios.cl',
        password: 'admin123'
      },
      warning: '⚠️ IMPORTANTE: Cambia la contraseña después del primer inicio de sesión'
    })
  } catch (error) {
    console.error('Error initializing database:', error)
    return NextResponse.json({ 
      success: false, 
      error: 'Error al inicializar la base de datos',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
